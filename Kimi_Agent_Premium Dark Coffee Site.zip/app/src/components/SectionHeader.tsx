import { motion } from 'framer-motion'

interface SectionHeaderProps {
  eyebrow?: string
  title: string
  subtitle?: string
  align?: 'left' | 'center'
}

export function SectionHeader({ eyebrow, title, subtitle, align = 'center' }: SectionHeaderProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-100px' }}
      transition={{ duration: 0.6 }}
      className={`mb-12 ${align === 'center' ? 'text-center' : 'text-left'}`}
    >
      {eyebrow && (
        <span className="text-[#C8A97E] text-xs font-medium uppercase tracking-[0.15em] mb-3 block">
          {eyebrow}
        </span>
      )}
      <h2 className="font-['Playfair_Display'] text-3xl md:text-4xl lg:text-[3rem] font-bold text-[#F5F0EB] leading-tight">
        {title}
      </h2>
      {subtitle && (
        <p className="mt-4 text-[#A8A29E] text-base md:text-lg max-w-2xl mx-auto leading-relaxed">
          {subtitle}
        </p>
      )}
    </motion.div>
  )
}
