import { useState, useRef, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Sparkles, Coffee, Flame, X, MessageCircle } from 'lucide-react'
import { trpc } from '@/providers/trpc'

interface Message {
  role: 'user' | 'assistant'
  content: string
}

export function ChatWidget() {
  const [isOpen, setIsOpen] = useState(false)
  const [input, setInput] = useState('')
  const [messages, setMessages] = useState<Message[]>([
    { role: 'assistant', content: 'Welcome to NOIR Brew! I\'m your AI assistant. Ask me about our menu, hours, reservations, or anything about coffee!' }
  ])
  const [history, setHistory] = useState<{ role: 'user' | 'assistant'; content: string }[]>([])
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const chatMutation = trpc.ai.chat.useMutation()

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim() || chatMutation.isPending) return

    const userMessage = input.trim()
    setInput('')
    setMessages(prev => [...prev, { role: 'user', content: userMessage }])

    try {
      const result = await chatMutation.mutateAsync({
        message: userMessage,
        history,
      })

      setMessages(prev => [...prev, { role: 'assistant', content: result.reply }])
      setHistory(prev => [
        ...prev,
        { role: 'user', content: userMessage },
        { role: 'assistant', content: result.reply },
      ])
    } catch {
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: 'I apologize, but I\'m having trouble connecting right now. Please try again later or contact us directly at hello@noirbrew.com'
      }])
    }
  }

  return (
    <>
      {/* Floating Button */}
      <AnimatePresence>
        {!isOpen && (
          <motion.button
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0, opacity: 0 }}
            onClick={() => setIsOpen(true)}
            className="fixed bottom-6 right-6 z-50 w-14 h-14 bg-gradient-to-br from-[#C8A97E] to-[#B8860B] rounded-full flex items-center justify-center shadow-lg hover:shadow-xl transition-shadow"
          >
            <MessageCircle className="w-6 h-6 text-[#0A0A0A]" />
          </motion.button>
        )}
      </AnimatePresence>

      {/* Chat Panel */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            transition={{ duration: 0.3 }}
            className="fixed bottom-6 right-6 z-50 w-[380px] max-w-[calc(100vw-3rem)] h-[520px] bg-[#141210] border border-[rgba(200,169,126,0.15)] rounded-2xl shadow-2xl flex flex-col overflow-hidden"
          >
            {/* Header */}
            <div className="flex items-center justify-between px-5 py-4 bg-gradient-to-r from-[#1C1917] to-[#141210] border-b border-[rgba(200,169,126,0.1)]">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-full bg-gradient-to-br from-[#C8A97E] to-[#B8860B] flex items-center justify-center">
                  <Sparkles className="w-5 h-5 text-[#0A0A0A]" />
                </div>
                <div>
                  <h3 className="text-[#F5F0EB] text-sm font-semibold">NOIR Assistant</h3>
                  <p className="text-[#6B6560] text-xs">AI-powered coffee guide</p>
                </div>
              </div>
              <button
                onClick={() => setIsOpen(false)}
                className="w-8 h-8 rounded-full bg-[#1C1917] flex items-center justify-center text-[#A8A29E] hover:text-[#F5F0EB] transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4">
              {messages.map((msg, i) => (
                <div
                  key={i}
                  className={`flex gap-3 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}
                >
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${
                    msg.role === 'assistant'
                      ? 'bg-gradient-to-br from-[#C8A97E] to-[#B8860B]'
                      : 'bg-[#2A2520]'
                  }`}>
                    {msg.role === 'assistant' ? (
                      <Sparkles className="w-4 h-4 text-[#0A0A0A]" />
                    ) : (
                      <Coffee className="w-4 h-4 text-[#C8A97E]" />
                    )}
                  </div>
                  <div
                    className={`max-w-[75%] px-4 py-3 rounded-2xl text-sm leading-relaxed ${
                      msg.role === 'assistant'
                        ? 'bg-[#1C1917] text-[#F5F0EB] rounded-tl-sm'
                        : 'bg-[#C8A97E]/15 text-[#F5F0EB] rounded-tr-sm border border-[#C8A97E]/20'
                    }`}
                  >
                    {msg.content}
                  </div>
                </div>
              ))}
              {chatMutation.isPending && (
                <div className="flex gap-3">
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#C8A97E] to-[#B8860B] flex items-center justify-center shrink-0">
                    <Sparkles className="w-4 h-4 text-[#0A0A0A]" />
                  </div>
                  <div className="bg-[#1C1917] rounded-2xl rounded-tl-sm px-4 py-3">
                    <div className="flex gap-1">
                      <span className="w-2 h-2 bg-[#C8A97E] rounded-full animate-bounce" />
                      <span className="w-2 h-2 bg-[#C8A97E] rounded-full animate-bounce" style={{ animationDelay: '0.1s' }} />
                      <span className="w-2 h-2 bg-[#C8A97E] rounded-full animate-bounce" style={{ animationDelay: '0.2s' }} />
                    </div>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Input */}
            <form onSubmit={handleSubmit} className="px-5 py-4 border-t border-[rgba(200,169,126,0.1)]">
              <div className="flex gap-3">
                <input
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Ask about our coffee..."
                  className="flex-1 bg-[#1C1917] border border-[rgba(200,169,126,0.15)] rounded-xl px-4 py-3 text-sm text-[#F5F0EB] placeholder-[#6B6560] focus:outline-none focus:border-[#C8A97E]/50 transition-colors"
                />
                <button
                  type="submit"
                  disabled={!input.trim() || chatMutation.isPending}
                  className="w-11 h-11 bg-gradient-to-br from-[#C8A97E] to-[#B8860B] rounded-xl flex items-center justify-center disabled:opacity-40 disabled:cursor-not-allowed hover:shadow-lg transition-all"
                >
                  <Flame className="w-5 h-5 text-[#0A0A0A]" />
                </button>
              </div>
            </form>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}
