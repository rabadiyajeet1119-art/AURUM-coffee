import { Link } from 'react-router'
import { MapPin, Phone, Mail, Clock, Instagram, Facebook, Twitter } from 'lucide-react'

const quickLinks = [
  { label: 'Home', href: '/' },
  { label: 'Menu', href: '/menu' },
  { label: 'About', href: '/about' },
  { label: 'Gallery', href: '/gallery' },
  { label: 'Order', href: '/order' },
  { label: 'Reservations', href: '/reservations' },
  { label: 'Contact', href: '/contact' },
]

export function Footer() {
  return (
    <footer className="bg-[#0D0B0A] border-t border-[rgba(200,169,126,0.1)]">
      <div className="container-premium py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Brand */}
          <div>
            <Link to="/" className="inline-block">
              <span className="font-['Playfair_Display'] text-3xl font-bold text-[#C8A97E]">
                NOIR
              </span>
            </Link>
            <p className="mt-4 text-[#A8A29E] text-sm leading-relaxed">
              Crafted with passion. Served with elegance. Experience the art of specialty coffee in an atmosphere of refined luxury.
            </p>
            <div className="flex gap-4 mt-6">
              <a href="#" className="w-10 h-10 rounded-full bg-[#1C1917] flex items-center justify-center text-[#A8A29E] hover:text-[#C8A97E] hover:bg-[#C8A97E]/10 transition-all">
                <Instagram className="w-4 h-4" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-[#1C1917] flex items-center justify-center text-[#A8A29E] hover:text-[#C8A97E] hover:bg-[#C8A97E]/10 transition-all">
                <Facebook className="w-4 h-4" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-[#1C1917] flex items-center justify-center text-[#A8A29E] hover:text-[#C8A97E] hover:bg-[#C8A97E]/10 transition-all">
                <Twitter className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-[#F5F0EB] font-semibold text-sm uppercase tracking-wider mb-6">
              Quick Links
            </h4>
            <ul className="space-y-3">
              {quickLinks.map((link) => (
                <li key={link.href}>
                  <Link
                    to={link.href}
                    className="text-[#A8A29E] text-sm hover:text-[#C8A97E] transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-[#F5F0EB] font-semibold text-sm uppercase tracking-wider mb-6">
              Contact Us
            </h4>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <MapPin className="w-4 h-4 text-[#C8A97E] mt-1 shrink-0" />
                <span className="text-[#A8A29E] text-sm">
                  123 Elegance Avenue, Suite 100<br />
                  New York, NY 10001
                </span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="w-4 h-4 text-[#C8A97E] shrink-0" />
                <span className="text-[#A8A29E] text-sm">+1 (555) 234-5678</span>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="w-4 h-4 text-[#C8A97E] shrink-0" />
                <span className="text-[#A8A29E] text-sm">hello@noirbrew.com</span>
              </li>
            </ul>
          </div>

          {/* Opening Hours */}
          <div>
            <h4 className="text-[#F5F0EB] font-semibold text-sm uppercase tracking-wider mb-6">
              Opening Hours
            </h4>
            <ul className="space-y-3">
              <li className="flex items-start gap-3">
                <Clock className="w-4 h-4 text-[#C8A97E] mt-0.5 shrink-0" />
                <div className="text-[#A8A29E] text-sm">
                  <p>Monday - Friday</p>
                  <p className="text-[#F5F0EB]">7:00 AM - 10:00 PM</p>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <Clock className="w-4 h-4 text-[#C8A97E] mt-0.5 shrink-0" />
                <div className="text-[#A8A29E] text-sm">
                  <p>Saturday - Sunday</p>
                  <p className="text-[#F5F0EB]">8:00 AM - 11:00 PM</p>
                </div>
              </li>
            </ul>

            {/* Newsletter */}
            <div className="mt-8">
              <h4 className="text-[#F5F0EB] font-semibold text-sm uppercase tracking-wider mb-3">
                Newsletter
              </h4>
              <div className="flex">
                <input
                  type="email"
                  placeholder="Your email"
                  className="flex-1 bg-[#1C1917] border border-[rgba(200,169,126,0.15)] rounded-l-lg px-3 py-2 text-sm text-[#F5F0EB] placeholder-[#6B6560] focus:outline-none focus:border-[#C8A97E]/50"
                />
                <button className="bg-[#C8A97E] text-[#0A0A0A] px-4 py-2 rounded-r-lg text-sm font-semibold hover:bg-[#D4B88A] transition-colors">
                  Join
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-[rgba(200,169,126,0.1)]">
        <div className="container-premium py-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-[#6B6560] text-sm">
            &copy; 2024 NOIR Brew. All rights reserved.
          </p>
          <div className="flex gap-6">
            <Link to="/faq" className="text-[#6B6560] text-sm hover:text-[#A8A29E] transition-colors">
              FAQ
            </Link>
            <Link to="/blog" className="text-[#6B6560] text-sm hover:text-[#A8A29E] transition-colors">
              Blog
            </Link>
            <Link to="/locations" className="text-[#6B6560] text-sm hover:text-[#A8A29E] transition-colors">
              Locations
            </Link>
          </div>
        </div>
      </div>
    </footer>
  )
}
