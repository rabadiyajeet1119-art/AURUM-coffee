import { Routes, Route } from 'react-router'
import { TRPCProvider } from './providers/trpc'
import { Navbar } from './components/Navbar'
import { Footer } from './components/Footer'
import { ChatWidget } from './components/ChatWidget'
import { Toaster } from '@/components/ui/sonner'
import Home from './pages/Home'
import Menu from './pages/Menu'
import About from './pages/About'
import Gallery from './pages/Gallery'
import Order from './pages/Order'
import Reservations from './pages/Reservations'
import Contact from './pages/Contact'
import Locations from './pages/Locations'
import Events from './pages/Events'
import FAQ from './pages/FAQ'
import Testimonials from './pages/Testimonials'
import Blog from './pages/Blog'
import Login from './pages/Login'
import Admin from './pages/Admin'
import NotFound from './pages/NotFound'

function AppContent() {
  return (
    <div className="min-h-screen bg-[#0A0A0A]">
      <Navbar />
      <main>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/menu" element={<Menu />} />
          <Route path="/about" element={<About />} />
          <Route path="/gallery" element={<Gallery />} />
          <Route path="/order" element={<Order />} />
          <Route path="/reservations" element={<Reservations />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/locations" element={<Locations />} />
          <Route path="/events" element={<Events />} />
          <Route path="/faq" element={<FAQ />} />
          <Route path="/testimonials" element={<Testimonials />} />
          <Route path="/blog" element={<Blog />} />
          <Route path="/login" element={<Login />} />
          <Route path="/admin" element={<Admin />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </main>
      <Footer />
      <ChatWidget />
      <Toaster position="top-right" theme="dark" />
    </div>
  )
}

export default function App() {
  return (
    <TRPCProvider>
      <AppContent />
    </TRPCProvider>
  )
}
