import { useState } from 'react'
import { motion } from 'framer-motion'
import { Cake, Briefcase, Users, Utensils, Send } from 'lucide-react'
import { trpc } from '@/providers/trpc'
import { toast } from 'sonner'

const services = [
  { icon: Cake, title: 'Birthday Celebrations', desc: 'Host an unforgettable birthday in our elegant private dining space. Custom menus, decor, and dedicated service.' },
  { icon: Briefcase, title: 'Corporate Events', desc: 'Professional meeting spaces with AV equipment, catering, and a refined atmosphere for productive gatherings.' },
  { icon: Users, title: 'Private Gatherings', desc: 'From intimate dinners to cocktail parties, our venue adapts to your vision with bespoke arrangements.' },
  { icon: Utensils, title: 'Catering Services', desc: 'Bring the NOIR experience to your location. Full-service catering for events of any size.' },
]

export default function Events() {
  const [form, setForm] = useState({ eventType: '', date: '', guests: '', name: '', email: '', phone: '', message: '' })
  const submitInquiry = trpc.contact.submit.useMutation({
    onSuccess: () => { toast.success('Inquiry submitted!'); setForm({ eventType: '', date: '', guests: '', name: '', email: '', phone: '', message: '' }) },
    onError: (err) => toast.error(err.message),
  })

  return (
    <div className="pt-[72px]">
      <section className="relative h-[40vh] flex items-center justify-center">
        <div className="absolute inset-0">
          <img src="/images/gallery-3.jpg" alt="Events" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-[#0A0A0A]/70" />
        </div>
        <div className="relative z-10 text-center">
          <h1 className="font-['Playfair_Display'] text-4xl md:text-5xl font-bold text-[#F5F0EB]">Events & Catering</h1>
        </div>
      </section>

      <section className="section-padding bg-[#0A0A0A]">
        <div className="container-premium">
          {/* Services */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
            {services.map((s, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="card-premium p-6 text-center"
              >
                <div className="w-14 h-14 mx-auto rounded-full bg-[#C8A97E]/10 flex items-center justify-center mb-4">
                  <s.icon className="w-6 h-6 text-[#C8A97E]" />
                </div>
                <h3 className="font-['Playfair_Display'] text-lg font-semibold text-[#F5F0EB]">{s.title}</h3>
                <p className="text-[#A8A29E] text-sm mt-3 leading-relaxed">{s.desc}</p>
              </motion.div>
            ))}
          </div>

          {/* Venue Details */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="bg-[#141210] rounded-xl border border-[rgba(200,169,126,0.1)] p-8 mb-16"
          >
            <h2 className="font-['Playfair_Display'] text-2xl font-bold text-[#F5F0EB] mb-6">Venue Details</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center p-4">
                <p className="text-3xl font-bold text-[#C8A97E]">80</p>
                <p className="text-[#A8A29E] text-sm mt-1">Seated Capacity</p>
              </div>
              <div className="text-center p-4">
                <p className="text-3xl font-bold text-[#C8A97E]">120</p>
                <p className="text-[#A8A29E] text-sm mt-1">Standing Capacity</p>
              </div>
              <div className="text-center p-4">
                <p className="text-3xl font-bold text-[#C8A97E]">2</p>
                <p className="text-[#A8A29E] text-sm mt-1">Private Rooms</p>
              </div>
            </div>
          </motion.div>

          {/* Inquiry Form */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="max-w-2xl mx-auto"
          >
            <h2 className="font-['Playfair_Display'] text-2xl font-bold text-[#F5F0EB] text-center mb-8">Event Inquiry</h2>
            <div className="bg-[#141210] rounded-xl border border-[rgba(200,169,126,0.1)] p-8">
              <form
                onSubmit={(e) => {
                  e.preventDefault()
                  submitInquiry.mutate({
                    name: form.name, email: form.email, phone: form.phone,
                    subject: `Event: ${form.eventType}`, message: `Event: ${form.eventType}\nDate: ${form.date}\nGuests: ${form.guests}\n\n${form.message}`,
                  })
                }}
                className="space-y-4"
              >
                <select
                  value={form.eventType}
                  onChange={(e) => setForm({ ...form, eventType: e.target.value })}
                  className="w-full bg-[#1C1917] border border-[rgba(200,169,126,0.15)] rounded-lg px-4 py-3 text-[#F5F0EB] focus:outline-none focus:border-[#C8A97E]/50 appearance-none"
                >
                  <option value="" className="bg-[#1C1917]">Event Type</option>
                  <option value="Birthday" className="bg-[#1C1917]">Birthday</option>
                  <option value="Corporate" className="bg-[#1C1917]">Corporate</option>
                  <option value="Private Gathering" className="bg-[#1C1917]">Private Gathering</option>
                  <option value="Catering" className="bg-[#1C1917]">Catering</option>
                </select>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} className="bg-[#1C1917] border border-[rgba(200,169,126,0.15)] rounded-lg px-4 py-3 text-[#F5F0EB] focus:outline-none focus:border-[#C8A97E]/50" />
                  <input type="number" placeholder="Guest Count" value={form.guests} onChange={(e) => setForm({ ...form, guests: e.target.value })} className="bg-[#1C1917] border border-[rgba(200,169,126,0.15)] rounded-lg px-4 py-3 text-[#F5F0EB] placeholder-[#6B6560] focus:outline-none focus:border-[#C8A97E]/50" />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <input type="text" placeholder="Name *" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="bg-[#1C1917] border border-[rgba(200,169,126,0.15)] rounded-lg px-4 py-3 text-[#F5F0EB] placeholder-[#6B6560] focus:outline-none focus:border-[#C8A97E]/50" required />
                  <input type="email" placeholder="Email *" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="bg-[#1C1917] border border-[rgba(200,169,126,0.15)] rounded-lg px-4 py-3 text-[#F5F0EB] placeholder-[#6B6560] focus:outline-none focus:border-[#C8A97E]/50" required />
                </div>
                <input type="tel" placeholder="Phone" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} className="w-full bg-[#1C1917] border border-[rgba(200,169,126,0.15)] rounded-lg px-4 py-3 text-[#F5F0EB] placeholder-[#6B6560] focus:outline-none focus:border-[#C8A97E]/50" />
                <textarea placeholder="Tell us about your event" value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} className="w-full bg-[#1C1917] border border-[rgba(200,169,126,0.15)] rounded-lg px-4 py-3 text-[#F5F0EB] placeholder-[#6B6560] focus:outline-none focus:border-[#C8A97E]/50 resize-none h-24" />
                <button type="submit" disabled={submitInquiry.isPending} className="w-full btn-primary disabled:opacity-50">
                  <Send className="w-4 h-4" /> {submitInquiry.isPending ? 'Submitting...' : 'Submit Inquiry'}
                </button>
              </form>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  )
}
