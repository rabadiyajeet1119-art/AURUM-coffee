import { Link } from 'react-router'
import { motion } from 'framer-motion'
import { ChevronDown, Star, ArrowRight, Coffee, Award, Flame, Users, MapPin, Clock, Phone } from 'lucide-react'
import { SectionHeader } from '@/components/SectionHeader'
import { trpc } from '@/providers/trpc'

const fadeUp = {
  initial: { opacity: 0, y: 40 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true, margin: '-100px' as const },
  transition: { duration: 0.6, ease: [0.4, 0, 0.2, 1] as const }
}

const staggerContainer = {
  initial: {},
  whileInView: { transition: { staggerChildren: 0.1 } },
  viewport: { once: true, margin: '-100px' as const }
}

const staggerChild = {
  initial: { opacity: 0, y: 30 },
  whileInView: { opacity: 1, y: 0, transition: { duration: 0.5 } },
  viewport: { once: true, margin: '-100px' as const }
}

const features = [
  { icon: Coffee, title: 'Premium Beans', desc: 'Ethically sourced single-origin beans from the world\'s finest regions.' },
  { icon: Award, title: 'Master Roasters', desc: 'Small-batch roasting by skilled artisans for optimal flavor profiles.' },
  { icon: Flame, title: 'Artisan Craft', desc: 'Every drink handcrafted with precision, passion, and attention to detail.' },
  { icon: Users, title: 'Elegant Atmosphere', desc: 'A refined space designed for connection, contemplation, and comfort.' },
]

const testimonials = [
  { name: 'Sarah Mitchell', quote: 'The most exquisite coffee experience I\'ve ever had. The ambiance, the flavors, the service — absolutely impeccable.', rating: 5 },
  { name: 'James Chen', quote: 'NOIR Brew has become my daily ritual. Their cold brew is unlike anything else in the city.', rating: 5 },
  { name: 'Elena Rodriguez', quote: 'We hosted our company event here and it was perfect. The catering was exceptional and the venue is stunning.', rating: 5 },
]

export default function Home() {
  const { data: menuItems } = trpc.menu.list.useQuery({ category: 'Coffee' })
  const bestSellers = menuItems?.filter(item => item.badges?.includes('Best Seller')).slice(0, 3) ?? []

  return (
    <div>
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="/images/hero-bg.jpg"
            alt="NOIR Brew interior"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-[#0A0A0A]/40 via-[#0A0A0A]/60 to-[#0A0A0A]" />
        </div>

        <div className="relative z-10 container-premium text-center pt-20">
          <motion.span
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-[#C8A97E] text-xs font-medium uppercase tracking-[0.15em] mb-6 block"
          >
            Est. 2024
          </motion.span>

          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.1 }}
            className="font-['Playfair_Display'] text-4xl md:text-5xl lg:text-7xl font-bold text-[#F5F0EB] max-w-3xl mx-auto leading-tight"
          >
            Where Every Cup
            <br />
            <span className="text-[#C8A97E]">Tells a Story</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="mt-6 text-[#A8A29E] text-lg max-w-xl mx-auto leading-relaxed"
          >
            Experience the art of specialty coffee in an atmosphere of refined elegance
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.3 }}
            className="mt-10 flex flex-wrap items-center justify-center gap-4"
          >
            <Link to="/order" className="btn-primary">Order Now</Link>
            <Link to="/menu" className="btn-outline">View Menu</Link>
            <Link to="/reservations" className="btn-outline">Book a Table</Link>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1, duration: 0.6 }}
          className="absolute bottom-8 left-1/2 -translate-x-1/2"
        >
          <ChevronDown className="w-6 h-6 text-[#C8A97E] animate-bounce" />
        </motion.div>
      </section>

      {/* Featured Best Sellers */}
      <section className="section-padding bg-[#0A0A0A]">
        <div className="container-premium">
          <SectionHeader
            eyebrow="Signature Selection"
            title="Our Best Sellers"
            subtitle="Crafted with passion, brewed to perfection"
          />

          <motion.div {...staggerContainer} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {bestSellers.length > 0 ? bestSellers.map((item) => (
              <motion.div key={item.id} {...staggerChild}>
                <Link to="/menu" className="card-premium block group">
                  <div className="aspect-[4/3] overflow-hidden">
                    <img
                      src={item.image ?? '/images/hero-bg.jpg'}
                      alt={item.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                  </div>
                  <div className="p-5">
                    <span className="text-[#C8A97E] text-xs uppercase tracking-wider">{item.category}</span>
                    <h3 className="font-['Playfair_Display'] text-xl font-semibold text-[#F5F0EB] mt-2">{item.name}</h3>
                    <p className="text-[#A8A29E] text-sm mt-2 line-clamp-2">{item.description}</p>
                    <div className="flex items-center justify-between mt-4">
                      <span className="font-['Playfair_Display'] text-lg font-semibold text-[#C8A97E]">${item.price}</span>
                      <span className="text-xs text-[#C8A97E] border border-[#C8A97E]/30 px-3 py-1 rounded-full">{item.badges?.[0]}</span>
                    </div>
                  </div>
                </Link>
              </motion.div>
            )) : (
              // Fallback items
              [
                { name: 'Artisan Cappuccino', price: '5.50', img: '/images/cappuccino.jpg', desc: 'Silky microfoam over rich espresso, finished with a dusting of cocoa.' },
                { name: 'Classic Latte', price: '5.50', img: '/images/latte.jpg', desc: 'Smooth espresso with steamed milk, topped with a thin layer of foam.' },
                { name: 'Classic Tiramisu', price: '8.50', img: '/images/tiramisu.jpg', desc: 'Layers of espresso-soaked ladyfingers and mascarpone cream.' },
              ].map((item, i) => (
                <motion.div key={i} {...staggerChild}>
                  <Link to="/menu" className="card-premium block group">
                    <div className="aspect-[4/3] overflow-hidden">
                      <img src={item.img} alt={item.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                    </div>
                    <div className="p-5">
                      <h3 className="font-['Playfair_Display'] text-xl font-semibold text-[#F5F0EB]">{item.name}</h3>
                      <p className="text-[#A8A29E] text-sm mt-2 line-clamp-2">{item.desc}</p>
                      <span className="font-['Playfair_Display'] text-lg font-semibold text-[#C8A97E] mt-3 block">${item.price}</span>
                    </div>
                  </Link>
                </motion.div>
              ))
            )}
          </motion.div>
        </div>
      </section>

      {/* Brand Story Teaser */}
      <section className="section-padding bg-[#141210]">
        <div className="container-premium">
          <div className="grid grid-cols-1 lg:grid-cols-5 gap-12 items-center">
            <motion.div {...fadeUp} className="lg:col-span-3">
              <span className="text-[#C8A97E] text-xs font-medium uppercase tracking-[0.15em] mb-4 block">Our Story</span>
              <h2 className="font-['Playfair_Display'] text-3xl md:text-4xl font-bold text-[#F5F0EB] leading-tight">
                A Passion for<br />Perfection
              </h2>
              <p className="mt-6 text-[#A8A29E] leading-relaxed">
                Founded in 2024, NOIR Brew began with a simple belief: that every cup of coffee should be an experience. 
                We source the finest beans from around the world, roast them to perfection, and serve them in an 
                environment designed for connection and contemplation.
              </p>
              <p className="mt-4 text-[#A8A29E] leading-relaxed">
                Our master roasters bring decades of expertise to every batch, ensuring that each sip delivers 
                the complex flavors and aromas that define truly exceptional coffee.
              </p>
              <Link to="/about" className="inline-flex items-center gap-2 mt-6 text-[#C8A97E] hover:text-[#D4B88A] transition-colors font-medium">
                Learn More <ArrowRight className="w-4 h-4" />
              </Link>
            </motion.div>
            <motion.div {...fadeUp} transition={{ delay: 0.2 }} className="lg:col-span-2">
              <img
                src="/images/story.jpg"
                alt="Barista crafting latte art"
                className="rounded-xl w-full h-auto shadow-xl"
              />
            </motion.div>
          </div>
        </div>
      </section>

      {/* Menu Preview */}
      <section className="section-padding bg-[#0A0A0A]">
        <div className="container-premium">
          <SectionHeader
            eyebrow="Discover"
            title="From Our Menu"
            subtitle="A curated selection of our finest offerings"
          />

          <motion.div {...staggerContainer} className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { name: 'Espresso', img: '/images/espresso.jpg' },
              { name: 'Cold Brew', img: '/images/cold-brew.jpg' },
              { name: 'Matcha', img: '/images/matcha.jpg' },
              { name: 'Croissant', img: '/images/croissant.jpg' },
            ].map((item, i) => (
              <motion.div key={i} {...staggerChild}>
                <Link
                  to="/menu"
                  className="group relative block aspect-square bg-[#141210] rounded-xl overflow-hidden border border-[rgba(200,169,126,0.1)] hover:border-[rgba(200,169,126,0.3)] transition-all"
                >
                  <img
                    src={item.img}
                    alt={item.name}
                    className="absolute inset-0 w-full h-full object-cover opacity-60 group-hover:opacity-100 group-hover:scale-105 transition-all duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A0A] via-transparent to-transparent" />
                  <div className="absolute bottom-0 left-0 right-0 p-4">
                    <span className="text-[#C8A97E] text-xs uppercase tracking-wider">Explore</span>
                    <h3 className="font-['Playfair_Display'] text-lg font-semibold text-[#F5F0EB] mt-1">{item.name}</h3>
                  </div>
                </Link>
              </motion.div>
            ))}
          </motion.div>

          <div className="text-center mt-10">
            <Link to="/menu" className="btn-outline">View Full Menu</Link>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="section-padding bg-[#141210]">
        <div className="container-premium">
          <SectionHeader
            eyebrow="The Difference"
            title="Why Choose NOIR"
            subtitle="What sets us apart from the ordinary"
          />

          <motion.div {...staggerContainer} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, i) => (
              <motion.div key={i} {...staggerChild} className="text-center p-6">
                <div className="w-14 h-14 mx-auto rounded-full bg-[#C8A97E]/10 flex items-center justify-center mb-5">
                  <feature.icon className="w-6 h-6 text-[#C8A97E]" />
                </div>
                <h3 className="font-['Playfair_Display'] text-lg font-semibold text-[#F5F0EB]">{feature.title}</h3>
                <p className="text-[#A8A29E] text-sm mt-3 leading-relaxed">{feature.desc}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="section-padding bg-[#0A0A0A]">
        <div className="container-premium">
          <SectionHeader
            eyebrow="Testimonials"
            title="What Our Guests Say"
          />

          <motion.div {...staggerContainer} className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {testimonials.map((t, i) => (
              <motion.div key={i} {...staggerChild} className="card-premium p-6">
                <div className="flex gap-1 mb-4">
                  {Array.from({ length: t.rating }).map((_, j) => (
                    <Star key={j} className="w-4 h-4 fill-[#C8A97E] text-[#C8A97E]" />
                  ))}
                </div>
                <p className="text-[#F5F0EB] italic leading-relaxed">&ldquo;{t.quote}&rdquo;</p>
                <p className="text-[#A8A29E] text-sm font-medium mt-4">{t.name}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Gallery Preview */}
      <section className="section-padding bg-[#141210]">
        <div className="container-premium">
          <SectionHeader
            eyebrow="Gallery"
            title="A Glimpse Inside"
          />

          <motion.div {...fadeUp} className="grid grid-cols-2 md:grid-cols-3 gap-4">
            <div className="col-span-2 md:col-span-2 row-span-2">
              <Link to="/gallery" className="block h-full group">
                <div className="relative h-full min-h-[300px] rounded-xl overflow-hidden">
                  <img src="/images/gallery-1.jpg" alt="Cafe interior" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                  <div className="absolute inset-0 bg-black/30 group-hover:bg-black/20 transition-colors" />
                  <div className="absolute bottom-4 left-4">
                    <span className="text-[#C8A97E] text-xs uppercase">Interior</span>
                  </div>
                </div>
              </Link>
            </div>
            <Link to="/gallery" className="block group">
              <div className="relative aspect-square rounded-xl overflow-hidden">
                <img src="/images/gallery-2.jpg" alt="Coffee collection" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                <div className="absolute inset-0 bg-black/30 group-hover:bg-black/20 transition-colors" />
              </div>
            </Link>
            <Link to="/gallery" className="block group">
              <div className="relative aspect-square rounded-xl overflow-hidden">
                <img src="/images/gallery-3.jpg" alt="Evening ambiance" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                <div className="absolute inset-0 bg-black/30 group-hover:bg-black/20 transition-colors" />
              </div>
            </Link>
          </motion.div>

          <div className="text-center mt-8">
            <Link to="/gallery" className="btn-outline">Explore Gallery</Link>
          </div>
        </div>
      </section>

      {/* Location & Hours */}
      <section className="section-padding bg-[#0A0A0A]">
        <div className="container-premium">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <motion.div {...fadeUp}>
              <span className="text-[#C8A97E] text-xs font-medium uppercase tracking-[0.15em] mb-4 block">Visit Us</span>
              <h2 className="font-['Playfair_Display'] text-3xl md:text-4xl font-bold text-[#F5F0EB]">Find Your Way</h2>

              <div className="mt-8 space-y-6">
                <div className="flex items-start gap-4">
                  <MapPin className="w-5 h-5 text-[#C8A97E] mt-1 shrink-0" />
                  <div>
                    <p className="text-[#F5F0EB] font-medium">Address</p>
                    <p className="text-[#A8A29E] text-sm mt-1">123 Elegance Avenue, Suite 100<br />New York, NY 10001</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <Clock className="w-5 h-5 text-[#C8A97E] mt-1 shrink-0" />
                  <div>
                    <p className="text-[#F5F0EB] font-medium">Hours</p>
                    <div className="text-[#A8A29E] text-sm mt-1 space-y-1">
                      <p>Mon - Fri: 7:00 AM - 10:00 PM</p>
                      <p>Sat - Sun: 8:00 AM - 11:00 PM</p>
                    </div>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <Phone className="w-5 h-5 text-[#C8A97E] mt-1 shrink-0" />
                  <div>
                    <p className="text-[#F5F0EB] font-medium">Phone</p>
                    <p className="text-[#A8A29E] text-sm mt-1">+1 (555) 234-5678</p>
                  </div>
                </div>
              </div>

              <Link to="/locations" className="btn-primary mt-8 inline-flex">
                Get Directions
              </Link>
            </motion.div>

            <motion.div {...fadeUp} transition={{ delay: 0.2 }} className="rounded-xl overflow-hidden h-[400px] bg-[#141210] flex items-center justify-center border border-[rgba(200,169,126,0.1)]">
              <div className="text-center p-8">
                <MapPin className="w-12 h-12 text-[#C8A97E] mx-auto mb-4" />
                <p className="text-[#F5F0EB] font-medium">NOIR Brew</p>
                <p className="text-[#A8A29E] text-sm mt-2">123 Elegance Avenue<br />New York, NY 10001</p>
                <a
                  href="https://maps.google.com/?q=123+Elegance+Avenue+New+York+NY"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-[#C8A97E] text-sm mt-4 inline-block hover:underline"
                >
                  Open in Google Maps
                </a>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-24 bg-gradient-to-b from-[#0A0A0A] to-[#141210]">
        <div className="container-premium text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="font-['Playfair_Display'] text-3xl md:text-5xl font-bold text-[#F5F0EB]">
              Ready to Experience <span className="text-[#C8A97E]">NOIR</span>?
            </h2>
            <p className="mt-4 text-[#A8A29E] text-lg max-w-xl mx-auto">
              Visit us today or place an order for pickup or delivery
            </p>
            <div className="mt-10 flex flex-wrap items-center justify-center gap-4">
              <Link to="/order" className="btn-primary">Order Online</Link>
              <Link to="/reservations" className="btn-outline">Book a Table</Link>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  )
}
