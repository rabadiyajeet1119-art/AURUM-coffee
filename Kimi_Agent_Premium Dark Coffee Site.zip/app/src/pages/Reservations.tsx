import { useState } from 'react'
import { motion } from 'framer-motion'
import { Minus, Plus, Calendar, Clock, Users } from 'lucide-react'
import { trpc } from '@/providers/trpc'
import { toast } from 'sonner'

const timeSlots = [
  '7:00 AM', '7:30 AM', '8:00 AM', '8:30 AM', '9:00 AM', '9:30 AM',
  '10:00 AM', '10:30 AM', '11:00 AM', '11:30 AM', '12:00 PM', '12:30 PM',
  '1:00 PM', '1:30 PM', '2:00 PM', '2:30 PM', '3:00 PM', '3:30 PM',
  '4:00 PM', '4:30 PM', '5:00 PM', '5:30 PM', '6:00 PM', '6:30 PM',
  '7:00 PM', '7:30 PM', '8:00 PM', '8:30 PM', '9:00 PM',
]

export default function Reservations() {
  const [form, setForm] = useState({
    name: '', email: '', phone: '',
    date: '', time: '', guests: 2, specialRequests: ''
  })
  const [confirmed, setConfirmed] = useState(false)

  const createReservation = trpc.reservation.create.useMutation({
    onSuccess: () => {
      setConfirmed(true)
      toast.success('Reservation confirmed!')
    },
    onError: (err) => toast.error(err.message),
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!form.name || !form.email || !form.phone || !form.date || !form.time) {
      toast.error('Please fill in all required fields')
      return
    }
    createReservation.mutate({
      name: form.name,
      email: form.email,
      phone: form.phone,
      date: form.date,
      time: form.time,
      guests: form.guests,
      specialRequests: form.specialRequests || undefined,
    })
  }

  if (confirmed) {
    return (
      <div className="pt-[72px] min-h-screen flex items-center justify-center bg-[#0A0A0A]">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-center max-w-md mx-auto p-8"
        >
          <div className="w-20 h-20 mx-auto rounded-full bg-[#C8A97E]/15 flex items-center justify-center mb-6">
            <Calendar className="w-10 h-10 text-[#C8A97E]" />
          </div>
          <h2 className="font-['Playfair_Display'] text-3xl font-bold text-[#F5F0EB]">Reservation Confirmed</h2>
          <p className="text-[#A8A29E] mt-4">
            Thank you, {form.name}! Your table for {form.guests} is reserved for {form.date} at {form.time}.
          </p>
          <p className="text-[#6B6560] text-sm mt-6">
            A confirmation has been sent to {form.email}
          </p>
        </motion.div>
      </div>
    )
  }

  return (
    <div className="pt-[72px]">
      <section className="relative h-[40vh] flex items-center justify-center">
        <div className="absolute inset-0">
          <img src="/images/gallery-3.jpg" alt="Reservations" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-[#0A0A0A]/70" />
        </div>
        <div className="relative z-10 text-center">
          <h1 className="font-['Playfair_Display'] text-4xl md:text-5xl font-bold text-[#F5F0EB]">Book a Table</h1>
        </div>
      </section>

      <section className="section-padding bg-[#0A0A0A]">
        <div className="container-premium max-w-xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="bg-[#141210] rounded-xl border border-[rgba(200,169,126,0.1)] p-8"
          >
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Date */}
              <div>
                <label className="text-[#A8A29E] text-sm font-medium mb-2 flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-[#C8A97E]" /> Date
                </label>
                <input
                  type="date"
                  value={form.date}
                  onChange={(e) => setForm({ ...form, date: e.target.value })}
                  min={new Date().toISOString().split('T')[0]}
                  className="w-full bg-[#1C1917] border border-[rgba(200,169,126,0.15)] rounded-lg px-4 py-3 text-[#F5F0EB] focus:outline-none focus:border-[#C8A97E]/50"
                  required
                />
              </div>

              {/* Time */}
              <div>
                <label className="text-[#A8A29E] text-sm font-medium mb-2 flex items-center gap-2">
                  <Clock className="w-4 h-4 text-[#C8A97E]" /> Time
                </label>
                <div className="grid grid-cols-4 gap-2 max-h-40 overflow-y-auto p-1">
                  {timeSlots.map((slot) => (
                    <button
                      key={slot}
                      type="button"
                      onClick={() => setForm({ ...form, time: slot })}
                      className={`py-2 px-1 rounded-lg text-xs font-medium transition-all ${
                        form.time === slot
                          ? 'bg-[#C8A97E]/15 text-[#C8A97E] border border-[#C8A97E]/30'
                          : 'bg-[#1C1917] text-[#A8A29E] hover:text-[#F5F0EB] border border-transparent'
                      }`}
                    >
                      {slot}
                    </button>
                  ))}
                </div>
              </div>

              {/* Guests */}
              <div>
                <label className="text-[#A8A29E] text-sm font-medium mb-2 flex items-center gap-2">
                  <Users className="w-4 h-4 text-[#C8A97E]" /> Guests
                </label>
                <div className="flex items-center gap-4">
                  <button
                    type="button"
                    onClick={() => setForm({ ...form, guests: Math.max(1, form.guests - 1) })}
                    className="w-10 h-10 rounded-full bg-[#1C1917] flex items-center justify-center text-[#A8A29E] hover:text-[#C8A97E]"
                  >
                    <Minus className="w-4 h-4" />
                  </button>
                  <span className="text-[#F5F0EB] text-lg font-semibold w-8 text-center">{form.guests}</span>
                  <button
                    type="button"
                    onClick={() => setForm({ ...form, guests: Math.min(20, form.guests + 1) })}
                    className="w-10 h-10 rounded-full bg-[#1C1917] flex items-center justify-center text-[#A8A29E] hover:text-[#C8A97E]"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Contact */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <input
                  type="text"
                  placeholder="Full Name"
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  className="bg-[#1C1917] border border-[rgba(200,169,126,0.15)] rounded-lg px-4 py-3 text-[#F5F0EB] placeholder-[#6B6560] focus:outline-none focus:border-[#C8A97E]/50"
                  required
                />
                <input
                  type="email"
                  placeholder="Email"
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  className="bg-[#1C1917] border border-[rgba(200,169,126,0.15)] rounded-lg px-4 py-3 text-[#F5F0EB] placeholder-[#6B6560] focus:outline-none focus:border-[#C8A97E]/50"
                  required
                />
              </div>
              <input
                type="tel"
                placeholder="Phone Number"
                value={form.phone}
                onChange={(e) => setForm({ ...form, phone: e.target.value })}
                className="w-full bg-[#1C1917] border border-[rgba(200,169,126,0.15)] rounded-lg px-4 py-3 text-[#F5F0EB] placeholder-[#6B6560] focus:outline-none focus:border-[#C8A97E]/50"
                required
              />

              {/* Special Requests */}
              <textarea
                placeholder="Special requests (optional)"
                value={form.specialRequests}
                onChange={(e) => setForm({ ...form, specialRequests: e.target.value })}
                className="w-full bg-[#1C1917] border border-[rgba(200,169,126,0.15)] rounded-lg px-4 py-3 text-[#F5F0EB] placeholder-[#6B6560] focus:outline-none focus:border-[#C8A97E]/50 resize-none h-24"
              />

              <button
                type="submit"
                disabled={createReservation.isPending}
                className="w-full btn-primary disabled:opacity-50"
              >
                {createReservation.isPending ? 'Confirming...' : 'Confirm Reservation'}
              </button>
            </form>

            <p className="text-[#6B6560] text-xs text-center mt-4">
              By booking, you agree to our reservation policy. Cancellations must be made 2 hours prior.
            </p>
          </motion.div>
        </div>
      </section>
    </div>
  )
}
