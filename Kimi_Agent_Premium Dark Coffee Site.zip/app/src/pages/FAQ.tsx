import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { ChevronDown } from 'lucide-react'

const faqs = [
  { q: 'What are your opening hours?', a: 'We are open Monday through Friday from 7:00 AM to 10:00 PM, and Saturday through Sunday from 8:00 AM to 11:00 PM. Our kitchen closes one hour before closing time.' },
  { q: 'Do you offer delivery?', a: 'Yes! We offer both pickup and delivery through our Order Online page. Delivery is available within a 5-mile radius of our locations.' },
  { q: 'Do you have vegan or sugar-free options?', a: 'Absolutely. We offer several vegan options including our Matcha Latte (with oat milk), Avocado Toast, and select pastries. We also have sugar-free syrup alternatives for most beverages.' },
  { q: 'Is Wi-Fi available?', a: 'Yes, we offer complimentary high-speed Wi-Fi for all guests. Ask our staff for the password when you arrive.' },
  { q: 'Is parking available?', a: 'Yes, we have dedicated parking spaces at our Flagship location. Our Downtown location is near several public parking garages.' },
  { q: 'Can I pre-book a table?', a: 'Yes, we recommend booking a table in advance, especially for weekends. Visit our Reservations page to book online.' },
  { q: 'Do you accept custom orders?', a: 'Yes, we are happy to accommodate custom requests. For large custom orders, please contact us at least 48 hours in advance.' },
  { q: 'Do you host private events?', a: 'Yes! We offer private event hosting and catering services. Visit our Events & Catering page for more details and to submit an inquiry.' },
]

function FAQItem({ question, answer }: { question: string; answer: string }) {
  const [open, setOpen] = useState(false)

  return (
    <div className="border-b border-[rgba(200,169,126,0.1)]">
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-center justify-between py-5 text-left group"
      >
        <span className="text-[#F5F0EB] font-medium pr-4 group-hover:text-[#C8A97E] transition-colors">
          {question}
        </span>
        <ChevronDown
          className={`w-5 h-5 text-[#C8A97E] shrink-0 transition-transform duration-300 ${open ? 'rotate-180' : ''}`}
        />
      </button>
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="overflow-hidden"
          >
            <p className="text-[#A8A29E] pb-5 leading-relaxed">{answer}</p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

export default function FAQ() {
  return (
    <div className="pt-[72px]">
      <section className="relative h-[40vh] flex items-center justify-center">
        <div className="absolute inset-0">
          <img src="/images/espresso.jpg" alt="FAQ" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-[#0A0A0A]/70" />
        </div>
        <div className="relative z-10 text-center">
          <h1 className="font-['Playfair_Display'] text-4xl md:text-5xl font-bold text-[#F5F0EB]">FAQ</h1>
        </div>
      </section>

      <section className="section-padding bg-[#0A0A0A]">
        <div className="container-premium max-w-3xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="bg-[#141210] rounded-xl border border-[rgba(200,169,126,0.1)] p-8"
          >
            {faqs.map((faq, i) => (
              <FAQItem key={i} question={faq.q} answer={faq.a} />
            ))}
          </motion.div>
        </div>
      </section>
    </div>
  )
}
