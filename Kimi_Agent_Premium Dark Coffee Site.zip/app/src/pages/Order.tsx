import { useState } from 'react'
import { motion } from 'framer-motion'
import { Plus, Minus, ShoppingBag, Trash2, Tag } from 'lucide-react'
import { SectionHeader } from '@/components/SectionHeader'
import { useCartStore } from '@/stores/cartStore'
import { toast } from 'sonner'

const categories = ['All', 'Coffee', 'Tea', 'Beverage', 'Food']

const menuData = [
  { id: 1, name: 'Single Origin Espresso', price: '3.50', category: 'Coffee', image: '/images/espresso.jpg' },
  { id: 2, name: 'Double Espresso', price: '4.50', category: 'Coffee', image: '/images/espresso.jpg' },
  { id: 3, name: 'Artisan Cappuccino', price: '5.50', category: 'Coffee', image: '/images/cappuccino.jpg' },
  { id: 4, name: 'Classic Latte', price: '5.50', category: 'Coffee', image: '/images/latte.jpg' },
  { id: 5, name: 'Flat White', price: '5.00', category: 'Coffee', image: '/images/flat-white.jpg' },
  { id: 6, name: 'Signature Cold Brew', price: '6.00', category: 'Coffee', image: '/images/cold-brew.jpg' },
  { id: 7, name: 'Iced Latte', price: '6.50', category: 'Coffee', image: '/images/iced-latte.jpg' },
  { id: 8, name: 'Matcha Latte', price: '6.50', category: 'Tea', image: '/images/matcha.jpg' },
  { id: 9, name: 'Earl Grey', price: '4.50', category: 'Tea', image: '/images/matcha.jpg' },
  { id: 10, name: 'Hot Chocolate', price: '5.50', category: 'Beverage', image: '/images/hot-chocolate.jpg' },
  { id: 11, name: 'Avocado Toast', price: '12.00', category: 'Food', image: '/images/avocado-toast.jpg' },
  { id: 12, name: 'Almond Croissant', price: '5.50', category: 'Food', image: '/images/croissant.jpg' },
  { id: 13, name: 'Classic Tiramisu', price: '8.50', category: 'Food', image: '/images/tiramisu.jpg' },
  { id: 14, name: 'New York Cheesecake', price: '9.00', category: 'Food', image: '/images/cheesecake.jpg' },
]

export default function Order() {
  const [activeCategory, setActiveCategory] = useState('All')
  const [promoCode, setPromoCode] = useState('')
  const [orderType, setOrderType] = useState<'pickup' | 'delivery'>('pickup')
  const [instructions, setInstructions] = useState('')

  const {
    items, addItem, removeItem, updateQuantity, clearCart, getSubtotal, getItemCount
  } = useCartStore()

  const filtered = activeCategory === 'All'
    ? menuData
    : menuData.filter(item => item.category === activeCategory)

  const subtotal = getSubtotal()
  const tax = subtotal * 0.0875
  const total = subtotal + tax

  const handleCheckout = () => {
    if (items.length === 0) {
      toast.error('Your cart is empty')
      return
    }
    toast.success('Order placed successfully!')
    clearCart()
  }

  return (
    <div className="pt-[72px]">
      {/* Hero */}
      <section className="relative h-[30vh] flex items-center justify-center">
        <div className="absolute inset-0">
          <img src="/images/gallery-2.jpg" alt="Order" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-[#0A0A0A]/70" />
        </div>
        <div className="relative z-10 text-center">
          <h1 className="font-['Playfair_Display'] text-4xl md:text-5xl font-bold text-[#F5F0EB]">Order Online</h1>
        </div>
      </section>

      <section className="section-padding bg-[#0A0A0A]">
        <div className="container-premium">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Product List */}
            <div className="lg:col-span-2">
              {/* Category Filter */}
              <div className="flex gap-2 mb-8 overflow-x-auto pb-2">
                {categories.map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setActiveCategory(cat)}
                    className={`px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-all ${
                      activeCategory === cat
                        ? 'bg-[#C8A97E]/15 text-[#C8A97E] border border-[#C8A97E]/30'
                        : 'text-[#A8A29E] hover:text-[#F5F0EB] border border-transparent'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>

              {/* Products */}
              <div className="space-y-3">
                {filtered.map((item) => {
                  const cartItem = items.find((i) => i.id === item.id)
                  return (
                    <motion.div
                      key={item.id}
                      layout
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="flex items-center gap-4 bg-[#141210] rounded-xl p-4 border border-[rgba(200,169,126,0.08)]"
                    >
                      <img src={item.image} alt={item.name} className="w-16 h-16 rounded-lg object-cover" />
                      <div className="flex-1 min-w-0">
                        <h3 className="text-[#F5F0EB] font-medium text-sm truncate">{item.name}</h3>
                        <span className="text-[#C8A97E] font-semibold text-sm">${item.price}</span>
                      </div>
                      {cartItem ? (
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => updateQuantity(item.id, cartItem.quantity - 1)}
                            className="w-8 h-8 rounded-full bg-[#1C1917] flex items-center justify-center text-[#A8A29E] hover:text-[#C8A97E]"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="text-[#F5F0EB] text-sm w-6 text-center">{cartItem.quantity}</span>
                          <button
                            onClick={() => updateQuantity(item.id, cartItem.quantity + 1)}
                            className="w-8 h-8 rounded-full bg-[#1C1917] flex items-center justify-center text-[#A8A29E] hover:text-[#C8A97E]"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>
                      ) : (
                        <button
                          onClick={() => addItem({ id: item.id, name: item.name, price: item.price, image: item.image })}
                          className="w-9 h-9 rounded-full bg-[#C8A97E]/15 flex items-center justify-center hover:bg-[#C8A97E]/30 transition-colors"
                        >
                          <Plus className="w-4 h-4 text-[#C8A97E]" />
                        </button>
                      )}
                    </motion.div>
                  )
                })}
              </div>
            </div>

            {/* Cart Sidebar */}
            <div className="lg:col-span-1">
              <div className="sticky top-24 bg-[#141210] rounded-xl border border-[rgba(200,169,126,0.1)] p-6">
                <div className="flex items-center gap-3 mb-6">
                  <ShoppingBag className="w-5 h-5 text-[#C8A97E]" />
                  <h3 className="text-[#F5F0EB] font-semibold">Your Order ({getItemCount()})</h3>
                </div>

                {items.length === 0 ? (
                  <div className="text-center py-8">
                    <ShoppingBag className="w-12 h-12 text-[#3a3530] mx-auto mb-3" />
                    <p className="text-[#6B6560] text-sm">Your cart is empty</p>
                  </div>
                ) : (
                  <>
                    <div className="space-y-3 mb-6 max-h-60 overflow-y-auto">
                      {items.map((item) => (
                        <div key={item.id} className="flex items-center gap-3">
                          <img src={item.image} alt={item.name} className="w-10 h-10 rounded-lg object-cover" />
                          <div className="flex-1 min-w-0">
                            <p className="text-[#F5F0EB] text-sm truncate">{item.name}</p>
                            <p className="text-[#A8A29E] text-xs">x{item.quantity}</p>
                          </div>
                          <span className="text-[#C8A97E] text-sm">${(parseFloat(item.price) * item.quantity).toFixed(2)}</span>
                          <button onClick={() => removeItem(item.id)} className="text-[#6B6560] hover:text-red-400">
                            <Trash2 className="w-3 h-3" />
                          </button>
                        </div>
                      ))}
                    </div>

                    {/* Order Type */}
                    <div className="flex gap-2 mb-4">
                      <button
                        onClick={() => setOrderType('pickup')}
                        className={`flex-1 py-2 rounded-lg text-xs font-medium transition-all ${
                          orderType === 'pickup' ? 'bg-[#C8A97E]/15 text-[#C8A97E] border border-[#C8A97E]/30' : 'bg-[#1C1917] text-[#A8A29E]'
                        }`}
                      >
                        Pickup
                      </button>
                      <button
                        onClick={() => setOrderType('delivery')}
                        className={`flex-1 py-2 rounded-lg text-xs font-medium transition-all ${
                          orderType === 'delivery' ? 'bg-[#C8A97E]/15 text-[#C8A97E] border border-[#C8A97E]/30' : 'bg-[#1C1917] text-[#A8A29E]'
                        }`}
                      >
                        Delivery
                      </button>
                    </div>

                    {/* Special Instructions */}
                    <textarea
                      value={instructions}
                      onChange={(e) => setInstructions(e.target.value)}
                      placeholder="Special instructions..."
                      className="w-full bg-[#1C1917] border border-[rgba(200,169,126,0.1)] rounded-lg px-3 py-2 text-sm text-[#F5F0EB] placeholder-[#6B6560] focus:outline-none focus:border-[#C8A97E]/30 mb-4 resize-none h-20"
                    />

                    {/* Promo */}
                    <div className="flex gap-2 mb-4">
                      <Tag className="w-4 h-4 text-[#6B6560] mt-2" />
                      <input
                        type="text"
                        value={promoCode}
                        onChange={(e) => setPromoCode(e.target.value)}
                        placeholder="Promo code"
                        className="flex-1 bg-[#1C1917] border border-[rgba(200,169,126,0.1)] rounded-lg px-3 py-2 text-sm text-[#F5F0EB] placeholder-[#6B6560] focus:outline-none focus:border-[#C8A97E]/30"
                      />
                    </div>

                    {/* Totals */}
                    <div className="space-y-2 pt-4 border-t border-[rgba(200,169,126,0.1)]">
                      <div className="flex justify-between text-sm">
                        <span className="text-[#A8A29E]">Subtotal</span>
                        <span className="text-[#F5F0EB]">${subtotal.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-[#A8A29E]">Tax</span>
                        <span className="text-[#F5F0EB]">${tax.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between text-base font-semibold pt-2 border-t border-[rgba(200,169,126,0.1)]">
                        <span className="text-[#F5F0EB]">Total</span>
                        <span className="text-[#C8A97E]">${total.toFixed(2)}</span>
                      </div>
                    </div>

                    <button
                      onClick={handleCheckout}
                      className="w-full btn-primary mt-6"
                    >
                      Place Order
                    </button>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
