import { useState } from 'react'
import { motion } from 'framer-motion'
import { LogIn, UserPlus, Coffee, Eye, EyeOff } from 'lucide-react'
import { trpc } from '@/providers/trpc'
import { toast } from 'sonner'

function getOAuthUrl() {
  const kimiAuthUrl = import.meta.env.VITE_KIMI_AUTH_URL
  const appID = import.meta.env.VITE_APP_ID
  const redirectUri = `${window.location.origin}/api/oauth/callback`
  const state = btoa(redirectUri)

  const url = new URL(`${kimiAuthUrl}/api/oauth/authorize`)
  url.searchParams.set('client_id', appID)
  url.searchParams.set('redirect_uri', redirectUri)
  url.searchParams.set('response_type', 'code')
  url.searchParams.set('scope', 'profile')
  url.searchParams.set('state', state)

  return url.toString()
}

export default function Login() {
  const [mode, setMode] = useState<'login' | 'register'>('login')
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [displayName, setDisplayName] = useState('')
  const [email, setEmail] = useState('')
  const [showPassword, setShowPassword] = useState(false)

  const loginMutation = trpc.localAuth.login.useMutation({
    onSuccess: (data) => {
      localStorage.setItem('local_auth_token', data.token)
      toast.success('Welcome back!')
      window.location.href = '/'
    },
    onError: (err) => toast.error(err.message),
  })

  const registerMutation = trpc.localAuth.register.useMutation({
    onSuccess: (data) => {
      localStorage.setItem('local_auth_token', data.token)
      toast.success('Account created!')
      window.location.href = '/'
    },
    onError: (err) => toast.error(err.message),
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!username || !password) {
      toast.error('Please fill in all required fields')
      return
    }
    if (mode === 'login') {
      loginMutation.mutate({ username, password })
    } else {
      if (password.length < 6) {
        toast.error('Password must be at least 6 characters')
        return
      }
      registerMutation.mutate({ username, password, displayName: displayName || undefined, email: email || undefined })
    }
  }

  const isPending = loginMutation.isPending || registerMutation.isPending

  return (
    <div className="pt-[72px] min-h-screen flex items-center justify-center bg-[#0A0A0A] px-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md"
      >
        <div className="bg-[#141210] rounded-xl border border-[rgba(200,169,126,0.1)] p-8">
          {/* Logo */}
          <div className="text-center mb-8">
            <Coffee className="w-10 h-10 text-[#C8A97E] mx-auto mb-3" />
            <h1 className="font-['Playfair_Display'] text-2xl font-bold text-[#F5F0EB]">
              {mode === 'login' ? 'Welcome Back' : 'Create Account'}
            </h1>
            <p className="text-[#A8A29E] text-sm mt-1">
              {mode === 'login' ? 'Sign in to your NOIR account' : 'Join the NOIR community'}
            </p>
          </div>

          {/* OAuth */}
          <a
            href={getOAuthUrl()}
            className="w-full flex items-center justify-center gap-2 py-3 bg-[#1C1917] border border-[rgba(200,169,126,0.15)] rounded-lg text-[#F5F0EB] text-sm font-medium hover:border-[#C8A97E]/30 transition-colors mb-6"
          >
            <LogIn className="w-4 h-4" />
            Continue with Portal
          </a>

          <div className="relative mb-6">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-[rgba(200,169,126,0.1)]" />
            </div>
            <div className="relative flex justify-center">
              <span className="bg-[#141210] px-4 text-[#6B6560] text-xs">or</span>
            </div>
          </div>

          {/* Local Auth Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            <input
              type="text"
              placeholder="Username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full bg-[#1C1917] border border-[rgba(200,169,126,0.15)] rounded-lg px-4 py-3 text-[#F5F0EB] placeholder-[#6B6560] focus:outline-none focus:border-[#C8A97E]/50"
              required
            />

            {mode === 'register' && (
              <>
                <input
                  type="text"
                  placeholder="Display Name (optional)"
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  className="w-full bg-[#1C1917] border border-[rgba(200,169,126,0.15)] rounded-lg px-4 py-3 text-[#F5F0EB] placeholder-[#6B6560] focus:outline-none focus:border-[#C8A97E]/50"
                />
                <input
                  type="email"
                  placeholder="Email (optional)"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-[#1C1917] border border-[rgba(200,169,126,0.15)] rounded-lg px-4 py-3 text-[#F5F0EB] placeholder-[#6B6560] focus:outline-none focus:border-[#C8A97E]/50"
                />
              </>
            )}

            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-[#1C1917] border border-[rgba(200,169,126,0.15)] rounded-lg px-4 py-3 pr-12 text-[#F5F0EB] placeholder-[#6B6560] focus:outline-none focus:border-[#C8A97E]/50"
                required
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-[#6B6560] hover:text-[#A8A29E]"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>

            <button
              type="submit"
              disabled={isPending}
              className="w-full btn-primary disabled:opacity-50"
            >
              {mode === 'login' ? (
                <><LogIn className="w-4 h-4" /> {isPending ? 'Signing in...' : 'Sign In'}</>
              ) : (
                <><UserPlus className="w-4 h-4" /> {isPending ? 'Creating...' : 'Create Account'}</>
              )}
            </button>
          </form>

          <p className="text-center text-[#A8A29E] text-sm mt-6">
            {mode === 'login' ? (
              <>Don&apos;t have an account? <button onClick={() => setMode('register')} className="text-[#C8A97E] hover:underline">Create one</button></>
            ) : (
              <>Already have an account? <button onClick={() => setMode('login')} className="text-[#C8A97E] hover:underline">Sign in</button></>
            )}
          </p>
        </div>
      </motion.div>
    </div>
  )
}
