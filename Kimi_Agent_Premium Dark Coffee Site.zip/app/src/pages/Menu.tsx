import { useState } from 'react'
import { motion } from 'framer-motion'
import { Plus, Star } from 'lucide-react'
import { SectionHeader } from '@/components/SectionHeader'
import { useCartStore } from '@/stores/cartStore'
import { toast } from 'sonner'

const categories = ['All', 'Coffee', 'Tea', 'Beverage', 'Food']

const menuData = [
  { id: 1, name: 'Single Origin Espresso', description: 'Rich, complex espresso crafted from ethically sourced single-origin beans.', price: '3.50', category: 'Coffee', image: '/images/espresso.jpg', badges: ['Best Seller'] },
  { id: 2, name: 'Double Espresso', description: 'An intense double shot of our house blend.', price: '4.50', category: 'Coffee', image: '/images/espresso.jpg', badges: [] },
  { id: 3, name: 'Artisan Cappuccino', description: 'Silky microfoam over rich espresso, finished with cocoa.', price: '5.50', category: 'Coffee', image: '/images/cappuccino.jpg', badges: ['Best Seller', 'Recommended'] },
  { id: 4, name: 'Classic Latte', description: 'Smooth espresso with steamed milk.', price: '5.50', category: 'Coffee', image: '/images/latte.jpg', badges: [] },
  { id: 5, name: 'Flat White', description: 'Australian-style with velvety microfoam.', price: '5.00', category: 'Coffee', image: '/images/flat-white.jpg', badges: [] },
  { id: 6, name: 'Signature Cold Brew', description: 'Slow-steeped for 18 hours.', price: '6.00', category: 'Coffee', image: '/images/cold-brew.jpg', badges: ['New'] },
  { id: 7, name: 'Iced Latte', description: 'Espresso over ice with cold milk.', price: '6.50', category: 'Coffee', image: '/images/iced-latte.jpg', badges: [] },
  { id: 8, name: 'Matcha Latte', description: 'Ceremonial-grade Japanese matcha.', price: '6.50', category: 'Tea', image: '/images/matcha.jpg', badges: ['Recommended'] },
  { id: 9, name: 'Earl Grey', description: 'Classic bergamot-infused black tea.', price: '4.50', category: 'Tea', image: '/images/matcha.jpg', badges: [] },
  { id: 10, name: 'Hot Chocolate', description: 'Rich Belgian chocolate with steamed milk.', price: '5.50', category: 'Beverage', image: '/images/hot-chocolate.jpg', badges: [] },
  { id: 11, name: 'Avocado Toast', description: 'Sourdough with smashed avocado and microgreens.', price: '12.00', category: 'Food', image: '/images/avocado-toast.jpg', badges: ['Recommended'] },
  { id: 12, name: 'Almond Croissant', description: 'Buttery croissant with almond cream.', price: '5.50', category: 'Food', image: '/images/croissant.jpg', badges: [] },
  { id: 13, name: 'Classic Tiramisu', description: 'Espresso-soaked ladyfingers with mascarpone.', price: '8.50', category: 'Food', image: '/images/tiramisu.jpg', badges: ['Best Seller'] },
  { id: 14, name: 'New York Cheesecake', description: 'Creamy cheesecake with berry compote.', price: '9.00', category: 'Food', image: '/images/cheesecake.jpg', badges: [] },
]

export default function Menu() {
  const [activeCategory, setActiveCategory] = useState('All')
  const addItem = useCartStore((s) => s.addItem)

  const filtered = activeCategory === 'All'
    ? menuData
    : menuData.filter(item => item.category === activeCategory)

  const handleAdd = (item: typeof menuData[0]) => {
    addItem({ id: item.id, name: item.name, price: item.price, quantity: 1, image: item.image })
    toast.success(`${item.name} added to cart`)
  }

  return (
    <div className="pt-[72px]">
      {/* Hero Banner */}
      <section className="relative h-[40vh] flex items-center justify-center">
        <div className="absolute inset-0">
          <img src="/images/hero-bg.jpg" alt="Menu" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-[#0A0A0A]/70" />
        </div>
        <div className="relative z-10 text-center">
          <h1 className="font-['Playfair_Display'] text-4xl md:text-5xl font-bold text-[#F5F0EB]">Our Menu</h1>
          <p className="mt-3 text-[#A8A29E] text-lg">Crafted beverages and artisanal treats</p>
        </div>
      </section>

      {/* Category Tabs */}
      <section className="sticky top-[72px] z-30 bg-[#0A0A0A]/95 backdrop-blur-md border-b border-[rgba(200,169,126,0.1)]">
        <div className="container-premium">
          <div className="flex gap-1 py-3 overflow-x-auto">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-5 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-all ${
                  activeCategory === cat
                    ? 'bg-[#C8A97E]/15 text-[#C8A97E] border border-[#C8A97E]/30'
                    : 'text-[#A8A29E] hover:text-[#F5F0EB] border border-transparent'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Menu Grid */}
      <section className="section-padding bg-[#0A0A0A]">
        <div className="container-premium">
          <motion.div
            layout
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            {filtered.map((item) => (
              <motion.div
                key={item.id}
                layout
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4 }}
                className="card-premium group"
              >
                <div className="flex gap-4 p-4">
                  <div className="w-24 h-24 rounded-lg overflow-hidden shrink-0">
                    <img
                      src={item.image}
                      alt={item.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <h3 className="font-['Playfair_Display'] text-base font-semibold text-[#F5F0EB]">{item.name}</h3>
                        <p className="text-[#A8A29E] text-xs mt-1 line-clamp-2">{item.description}</p>
                      </div>
                      <button
                        onClick={() => handleAdd(item)}
                        className="w-8 h-8 rounded-full bg-[#C8A97E]/15 flex items-center justify-center shrink-0 hover:bg-[#C8A97E]/30 transition-colors"
                      >
                        <Plus className="w-4 h-4 text-[#C8A97E]" />
                      </button>
                    </div>
                    <div className="flex items-center gap-2 mt-3">
                      <span className="font-['Playfair_Display'] text-lg font-semibold text-[#C8A97E]">${item.price}</span>
                      {item.badges.map((badge) => (
                        <span key={badge} className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${
                          badge === 'Best Seller' ? 'bg-[#C8A97E]/15 text-[#C8A97E]' :
                          badge === 'New' ? 'bg-green-500/15 text-green-400' :
                          'bg-[#A8A29E]/15 text-[#A8A29E]'
                        }`}>
                          {badge === 'Best Seller' && <Star className="w-3 h-3 inline mr-1" />}
                          {badge}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>
    </div>
  )
}
