import { motion } from 'framer-motion'
import { Award, Leaf, Heart, Lightbulb, Coffee } from 'lucide-react'
import { SectionHeader } from '@/components/SectionHeader'

const fadeUp = {
  initial: { opacity: 0, y: 40 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true, margin: '-100px' as const },
  transition: { duration: 0.6 }
}

const values = [
  { icon: Award, title: 'Quality', desc: 'Only the finest beans and ingredients make it to your cup.' },
  { icon: Leaf, title: 'Sustainability', desc: 'Ethically sourced, environmentally conscious practices.' },
  { icon: Heart, title: 'Community', desc: 'Building connections one cup at a time.' },
  { icon: Lightbulb, title: 'Innovation', desc: 'Constantly exploring new flavors and techniques.' },
  { icon: Coffee, title: 'Hospitality', desc: 'Every guest is treated like family.' },
]

const processSteps = [
  { num: '01', title: 'Source', desc: 'We partner with trusted farms across Ethiopia, Colombia, and Guatemala to source the highest quality beans.' },
  { num: '02', title: 'Roast', desc: 'Our master roasters use precise temperature curves to unlock each bean\'s unique flavor profile.' },
  { num: '03', title: 'Brew', desc: 'Every cup is crafted with care using state-of-the-art equipment and time-honored techniques.' },
  { num: '04', title: 'Serve', desc: 'Presented in an elegant atmosphere designed to elevate your coffee experience.' },
]

export default function About() {
  return (
    <div className="pt-[72px]">
      {/* Hero */}
      <section className="relative h-[50vh] flex items-center justify-center">
        <div className="absolute inset-0">
          <img src="/images/story.jpg" alt="About" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-[#0A0A0A]/70" />
        </div>
        <div className="relative z-10 text-center">
          <h1 className="font-['Playfair_Display'] text-4xl md:text-5xl font-bold text-[#F5F0EB]">Our Story</h1>
        </div>
      </section>

      {/* Brand Story */}
      <section className="section-padding bg-[#141210]">
        <div className="container-premium max-w-4xl mx-auto text-center">
          <motion.div {...fadeUp}>
            <h2 className="font-['Playfair_Display'] text-3xl md:text-4xl font-bold text-[#F5F0EB]">
              Born from a Love of Coffee
            </h2>
            <p className="mt-6 text-[#A8A29E] leading-relaxed text-lg">
              NOIR Brew was founded on a simple yet powerful belief: that every cup of coffee should be a transcendent 
              experience. What started as a small passion project between two coffee enthusiasts has grown into a 
              destination for those who appreciate the finer things in life.
            </p>
            <p className="mt-4 text-[#A8A29E] leading-relaxed text-lg">
              We travel the world to find exceptional beans, partner with farmers who share our commitment to quality, 
              and roast each batch with meticulous care. Our café is more than a place to grab coffee — it is a sanctuary 
              for connection, creativity, and contemplation.
            </p>
            <blockquote className="mt-10 text-[#C8A97E] text-xl italic font-['Playfair_Display']">
              &ldquo;Coffee is not just a drink. It is a moment of pause in a chaotic world.&rdquo;
            </blockquote>
          </motion.div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="section-padding bg-[#0A0A0A]">
        <div className="container-premium">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <motion.div {...fadeUp} className="card-premium p-8">
              <h3 className="font-['Playfair_Display'] text-2xl font-bold text-[#C8A97E] mb-4">Our Mission</h3>
              <p className="text-[#A8A29E] leading-relaxed">
                To craft exceptional coffee experiences that inspire connection, creativity, and community. 
                We are dedicated to sourcing the world&apos;s finest beans, honoring the craft of roasting, 
                and creating spaces where every guest feels genuinely welcomed.
              </p>
            </motion.div>
            <motion.div {...fadeUp} transition={{ delay: 0.2 }} className="card-premium p-8">
              <h3 className="font-['Playfair_Display'] text-2xl font-bold text-[#C8A97E] mb-4">Our Vision</h3>
              <p className="text-[#A8A29E] leading-relaxed">
                To be the world&apos;s most beloved specialty coffee house — a brand synonymous with quality, 
                innovation, and warm hospitality. We envision a global community united by a shared passion 
                for extraordinary coffee and meaningful human connection.
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Process */}
      <section className="section-padding bg-[#141210]">
        <div className="container-premium">
          <SectionHeader eyebrow="Our Process" title="From Bean to Cup" />

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {processSteps.map((step, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="text-center"
              >
                <div className="w-16 h-16 mx-auto rounded-full bg-[#C8A97E]/10 flex items-center justify-center mb-4 border border-[#C8A97E]/20">
                  <span className="font-['Playfair_Display'] text-xl font-bold text-[#C8A97E]">{step.num}</span>
                </div>
                <h4 className="font-['Playfair_Display'] text-lg font-semibold text-[#F5F0EB]">{step.title}</h4>
                <p className="text-[#A8A29E] text-sm mt-3 leading-relaxed">{step.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Images */}
      <section className="py-12 bg-[#0A0A0A]">
        <div className="container-premium">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <motion.div initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }}>
              <img src="/images/sourcing.jpg" alt="Coffee sourcing" className="rounded-xl w-full h-64 object-cover" />
              <p className="text-[#A8A29E] text-sm mt-3 text-center">Ethical Sourcing</p>
            </motion.div>
            <motion.div initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }} transition={{ delay: 0.1 }}>
              <img src="/images/roasting.jpg" alt="Coffee roasting" className="rounded-xl w-full h-64 object-cover" />
              <p className="text-[#A8A29E] text-sm mt-3 text-center">Master Roasting</p>
            </motion.div>
            <motion.div initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }} transition={{ delay: 0.2 }}>
              <img src="/images/gallery-2.jpg" alt="Brewing" className="rounded-xl w-full h-64 object-cover" />
              <p className="text-[#A8A29E] text-sm mt-3 text-center">Artisan Brewing</p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Brand Values */}
      <section className="section-padding bg-[#141210]">
        <div className="container-premium">
          <SectionHeader eyebrow="What We Stand For" title="Our Values" />

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6">
            {values.map((v, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.08 }}
                className="text-center p-6"
              >
                <div className="w-12 h-12 mx-auto rounded-full bg-[#C8A97E]/10 flex items-center justify-center mb-4">
                  <v.icon className="w-5 h-5 text-[#C8A97E]" />
                </div>
                <h4 className="text-[#F5F0EB] font-semibold">{v.title}</h4>
                <p className="text-[#A8A29E] text-sm mt-2">{v.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  )
}
