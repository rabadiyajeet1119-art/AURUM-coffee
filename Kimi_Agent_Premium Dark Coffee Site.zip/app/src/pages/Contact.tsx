import { useState } from 'react'
import { motion } from 'framer-motion'
import { MapPin, Phone, Mail, Clock, Send } from 'lucide-react'
import { trpc } from '@/providers/trpc'
import { toast } from 'sonner'

export default function Contact() {
  const [form, setForm] = useState({ name: '', email: '', phone: '', subject: '', message: '' })
  const submitMessage = trpc.contact.submit.useMutation({
    onSuccess: () => {
      toast.success('Message sent successfully!')
      setForm({ name: '', email: '', phone: '', subject: '', message: '' })
    },
    onError: (err) => toast.error(err.message),
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!form.name || !form.email || !form.message) {
      toast.error('Please fill in required fields')
      return
    }
    submitMessage.mutate(form)
  }

  return (
    <div className="pt-[72px]">
      <section className="relative h-[40vh] flex items-center justify-center">
        <div className="absolute inset-0">
          <img src="/images/gallery-1.jpg" alt="Contact" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-[#0A0A0A]/70" />
        </div>
        <div className="relative z-10 text-center">
          <h1 className="font-['Playfair_Display'] text-4xl md:text-5xl font-bold text-[#F5F0EB]">Contact Us</h1>
        </div>
      </section>

      <section className="section-padding bg-[#0A0A0A]">
        <div className="container-premium">
          <div className="grid grid-cols-1 lg:grid-cols-5 gap-12">
            {/* Contact Form */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="lg:col-span-3"
            >
              <div className="bg-[#141210] rounded-xl border border-[rgba(200,169,126,0.1)] p-8">
                <h2 className="font-['Playfair_Display'] text-2xl font-bold text-[#F5F0EB] mb-6">Send a Message</h2>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <input
                      type="text" placeholder="Name *" value={form.name}
                      onChange={(e) => setForm({ ...form, name: e.target.value })}
                      className="bg-[#1C1917] border border-[rgba(200,169,126,0.15)] rounded-lg px-4 py-3 text-[#F5F0EB] placeholder-[#6B6560] focus:outline-none focus:border-[#C8A97E]/50"
                      required
                    />
                    <input
                      type="email" placeholder="Email *" value={form.email}
                      onChange={(e) => setForm({ ...form, email: e.target.value })}
                      className="bg-[#1C1917] border border-[rgba(200,169,126,0.15)] rounded-lg px-4 py-3 text-[#F5F0EB] placeholder-[#6B6560] focus:outline-none focus:border-[#C8A97E]/50"
                      required
                    />
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <input
                      type="tel" placeholder="Phone" value={form.phone}
                      onChange={(e) => setForm({ ...form, phone: e.target.value })}
                      className="bg-[#1C1917] border border-[rgba(200,169,126,0.15)] rounded-lg px-4 py-3 text-[#F5F0EB] placeholder-[#6B6560] focus:outline-none focus:border-[#C8A97E]/50"
                    />
                    <select
                      value={form.subject}
                      onChange={(e) => setForm({ ...form, subject: e.target.value })}
                      className="bg-[#1C1917] border border-[rgba(200,169,126,0.15)] rounded-lg px-4 py-3 text-[#F5F0EB] focus:outline-none focus:border-[#C8A97E]/50 appearance-none"
                    >
                      <option value="" className="bg-[#1C1917]">Select Subject</option>
                      <option value="General Inquiry" className="bg-[#1C1917]">General Inquiry</option>
                      <option value="Feedback" className="bg-[#1C1917]">Feedback</option>
                      <option value="Partnership" className="bg-[#1C1917]">Partnership</option>
                      <option value="Other" className="bg-[#1C1917]">Other</option>
                    </select>
                  </div>
                  <textarea
                    placeholder="Your message *" value={form.message}
                    onChange={(e) => setForm({ ...form, message: e.target.value })}
                    className="w-full bg-[#1C1917] border border-[rgba(200,169,126,0.15)] rounded-lg px-4 py-3 text-[#F5F0EB] placeholder-[#6B6560] focus:outline-none focus:border-[#C8A97E]/50 resize-none h-32"
                    required
                  />
                  <button type="submit" disabled={submitMessage.isPending} className="btn-primary disabled:opacity-50">
                    <Send className="w-4 h-4" />
                    {submitMessage.isPending ? 'Sending...' : 'Send Message'}
                  </button>
                </form>
              </div>
            </motion.div>

            {/* Contact Info */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2 }}
              className="lg:col-span-2 space-y-6"
            >
              <div className="bg-[#141210] rounded-xl border border-[rgba(200,169,126,0.1)] p-6">
                <h3 className="text-[#F5F0EB] font-semibold mb-4">Contact Information</h3>
                <div className="space-y-4">
                  <div className="flex items-start gap-3">
                    <MapPin className="w-5 h-5 text-[#C8A97E] mt-0.5 shrink-0" />
                    <p className="text-[#A8A29E] text-sm">123 Elegance Avenue, Suite 100<br />New York, NY 10001</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <Phone className="w-5 h-5 text-[#C8A97E] shrink-0" />
                    <p className="text-[#A8A29E] text-sm">+1 (555) 234-5678</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <Mail className="w-5 h-5 text-[#C8A97E] shrink-0" />
                    <p className="text-[#A8A29E] text-sm">hello@noirbrew.com</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <Clock className="w-5 h-5 text-[#C8A97E] mt-0.5 shrink-0" />
                    <div className="text-[#A8A29E] text-sm">
                      <p>Mon - Fri: 7:00 AM - 10:00 PM</p>
                      <p>Sat - Sun: 8:00 AM - 11:00 PM</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-[#141210] rounded-xl border border-[rgba(200,169,126,0.1)] p-6">
                <h3 className="text-[#F5F0EB] font-semibold mb-4">Quick Actions</h3>
                <div className="space-y-3">
                  <a href="tel:+15552345678" className="block w-full text-center py-3 bg-[#C8A97E]/10 text-[#C8A97E] rounded-lg text-sm font-medium hover:bg-[#C8A97E]/20 transition-colors">
                    Call Us
                  </a>
                  <a href="https://wa.me/15552345678" target="_blank" rel="noopener noreferrer" className="block w-full text-center py-3 bg-green-500/10 text-green-400 rounded-lg text-sm font-medium hover:bg-green-500/20 transition-colors">
                    WhatsApp
                  </a>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>
    </div>
  )
}
