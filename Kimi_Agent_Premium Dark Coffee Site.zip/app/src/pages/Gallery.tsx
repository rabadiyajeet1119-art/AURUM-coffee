import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { X, ChevronLeft, ChevronRight } from 'lucide-react'

const categories = ['All', 'Interior', 'Coffee', 'Food', 'Lifestyle']

const galleryImages = [
  { src: '/images/gallery-1.jpg', category: 'Interior', title: 'Main Lounge' },
  { src: '/images/gallery-2.jpg', category: 'Coffee', title: 'Signature Collection' },
  { src: '/images/gallery-3.jpg', category: 'Interior', title: 'Evening Ambiance' },
  { src: '/images/story.jpg', category: 'Lifestyle', title: 'Craft in Action' },
  { src: '/images/roasting.jpg', category: 'Coffee', title: 'The Roast' },
  { src: '/images/sourcing.jpg', category: 'Lifestyle', title: 'Origin' },
  { src: '/images/hero-bg.jpg', category: 'Interior', title: 'The Bar' },
  { src: '/images/latte.jpg', category: 'Coffee', title: 'Latte Art' },
  { src: '/images/tiramisu.jpg', category: 'Food', title: 'Classic Tiramisu' },
  { src: '/images/croissant.jpg', category: 'Food', title: 'Almond Croissant' },
  { src: '/images/flat-white.jpg', category: 'Coffee', title: 'Flat White' },
  { src: '/images/avocado-toast.jpg', category: 'Food', title: 'Avocado Toast' },
]

export default function Gallery() {
  const [activeCategory, setActiveCategory] = useState('All')
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null)

  const filtered = activeCategory === 'All'
    ? galleryImages
    : galleryImages.filter(img => img.category === activeCategory)

  const openLightbox = (index: number) => setLightboxIndex(index)
  const closeLightbox = () => setLightboxIndex(null)
  const prevImage = () => setLightboxIndex(prev => prev !== null ? (prev - 1 + filtered.length) % filtered.length : null)
  const nextImage = () => setLightboxIndex(prev => prev !== null ? (prev + 1) % filtered.length : null)

  return (
    <div className="pt-[72px]">
      {/* Hero */}
      <section className="relative h-[40vh] flex items-center justify-center">
        <div className="absolute inset-0">
          <img src="/images/gallery-1.jpg" alt="Gallery" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-[#0A0A0A]/70" />
        </div>
        <div className="relative z-10 text-center">
          <h1 className="font-['Playfair_Display'] text-4xl md:text-5xl font-bold text-[#F5F0EB]">Gallery</h1>
        </div>
      </section>

      {/* Filters */}
      <section className="sticky top-[72px] z-30 bg-[#0A0A0A]/95 backdrop-blur-md border-b border-[rgba(200,169,126,0.1)]">
        <div className="container-premium">
          <div className="flex gap-2 py-3 overflow-x-auto">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-5 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-all ${
                  activeCategory === cat
                    ? 'bg-[#C8A97E]/15 text-[#C8A97E] border border-[#C8A97E]/30'
                    : 'text-[#A8A29E] hover:text-[#F5F0EB] border border-transparent'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Gallery Grid */}
      <section className="section-padding bg-[#0A0A0A]">
        <div className="container-premium">
          <motion.div layout className="columns-1 sm:columns-2 lg:columns-3 gap-4">
            {filtered.map((img, i) => (
              <motion.div
                key={img.src}
                layout
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.4 }}
                className="mb-4 break-inside-avoid"
              >
                <button
                  onClick={() => openLightbox(i)}
                  className="group relative block w-full overflow-hidden rounded-lg"
                >
                  <img
                    src={img.src}
                    alt={img.title}
                    className="w-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition-colors flex items-end p-4">
                    <span className="text-[#F5F0EB] text-sm font-medium opacity-0 group-hover:opacity-100 transition-opacity translate-y-2 group-hover:translate-y-0">
                      {img.title}
                    </span>
                  </div>
                </button>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Lightbox */}
      <AnimatePresence>
        {lightboxIndex !== null && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center"
            onClick={closeLightbox}
          >
            <button
              onClick={closeLightbox}
              className="absolute top-6 right-6 w-10 h-10 rounded-full bg-[#1C1917] flex items-center justify-center text-[#F5F0EB] hover:bg-[#C8A97E]/20 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <button
              onClick={(e) => { e.stopPropagation(); prevImage() }}
              className="absolute left-4 md:left-8 w-10 h-10 rounded-full bg-[#1C1917] flex items-center justify-center text-[#F5F0EB] hover:bg-[#C8A97E]/20 transition-colors"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>

            <button
              onClick={(e) => { e.stopPropagation(); nextImage() }}
              className="absolute right-4 md:right-8 w-10 h-10 rounded-full bg-[#1C1917] flex items-center justify-center text-[#F5F0EB] hover:bg-[#C8A97E]/20 transition-colors"
            >
              <ChevronRight className="w-5 h-5" />
            </button>

            <motion.img
              key={filtered[lightboxIndex]?.src}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              src={filtered[lightboxIndex]?.src}
              alt={filtered[lightboxIndex]?.title}
              className="max-w-[90vw] max-h-[85vh] object-contain rounded-lg"
              onClick={(e) => e.stopPropagation()}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
