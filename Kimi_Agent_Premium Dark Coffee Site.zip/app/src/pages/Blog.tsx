import { motion } from 'framer-motion'
import { ArrowRight, Clock } from 'lucide-react'
import { Link } from 'react-router'

const posts = [
  {
    title: 'The Art of Pour-Over: A Beginner\'s Guide',
    excerpt: 'Discover the meditative practice of pour-over coffee brewing and learn how to achieve café-quality results at home with our step-by-step guide.',
    category: 'Brewing Guides',
    date: 'Dec 15, 2024',
    readTime: '5 min',
    image: '/images/story.jpg',
  },
  {
    title: 'Understanding Coffee Origins: Ethiopia vs Colombia',
    excerpt: 'Explore the distinct flavor profiles of two of the world\'s most celebrated coffee regions and discover which suits your palate best.',
    category: 'Coffee Tips',
    date: 'Dec 8, 2024',
    readTime: '7 min',
    image: '/images/sourcing.jpg',
  },
  {
    title: 'Winter Seasonal Menu: Cozy Creations',
    excerpt: 'Introducing our new winter collection featuring warming spices, rich chocolate notes, and comforting flavors to embrace the season.',
    category: 'Seasonal',
    date: 'Nov 28, 2024',
    readTime: '4 min',
    image: '/images/hot-chocolate.jpg',
  },
  {
    title: 'Behind the Scenes: A Day with Our Master Roaster',
    excerpt: 'Follow along as we shadow our head roaster through a typical day, from green bean selection to the final cooling tray.',
    category: 'Behind the Scenes',
    date: 'Nov 20, 2024',
    readTime: '6 min',
    image: '/images/roasting.jpg',
  },
  {
    title: 'Latte Art: From Heart to Rosetta',
    excerpt: 'Learn the fundamentals of latte art with tips from our barista champions on milk texture, pour technique, and pattern creation.',
    category: 'Brewing Guides',
    date: 'Nov 12, 2024',
    readTime: '8 min',
    image: '/images/latte.jpg',
  },
  {
    title: 'NOIR Brew Named Best Café in NYC',
    excerpt: 'We are honored to be recognized by the City Dining Awards as the best specialty coffee house in New York for 2024.',
    category: 'News',
    date: 'Nov 5, 2024',
    readTime: '3 min',
    image: '/images/gallery-1.jpg',
  },
]

const categories = ['All', 'Coffee Tips', 'Brewing Guides', 'Seasonal', 'Behind the Scenes', 'News']

export default function Blog() {
  return (
    <div className="pt-[72px]">
      <section className="relative h-[40vh] flex items-center justify-center">
        <div className="absolute inset-0">
          <img src="/images/roasting.jpg" alt="Blog" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-[#0A0A0A]/70" />
        </div>
        <div className="relative z-10 text-center">
          <h1 className="font-['Playfair_Display'] text-4xl md:text-5xl font-bold text-[#F5F0EB]">Blog</h1>
          <p className="mt-3 text-[#A8A29E]">Stories, tips, and coffee culture</p>
        </div>
      </section>

      <section className="section-padding bg-[#0A0A0A]">
        <div className="container-premium">
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
            {/* Posts */}
            <div className="lg:col-span-3">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {posts.map((post, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.05 }}
                    className="card-premium group"
                  >
                    <div className="aspect-[16/10] overflow-hidden">
                      <img
                        src={post.image}
                        alt={post.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                    </div>
                    <div className="p-5">
                      <span className="text-[#C8A97E] text-xs uppercase tracking-wider">{post.category}</span>
                      <h3 className="font-['Playfair_Display'] text-lg font-semibold text-[#F5F0EB] mt-2 group-hover:text-[#C8A97E] transition-colors">
                        {post.title}
                      </h3>
                      <p className="text-[#A8A29E] text-sm mt-2 line-clamp-2">{post.excerpt}</p>
                      <div className="flex items-center justify-between mt-4">
                        <div className="flex items-center gap-3 text-xs text-[#6B6560]">
                          <span>{post.date}</span>
                          <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> {post.readTime}</span>
                        </div>
                        <span className="text-[#C8A97E] text-sm flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          Read <ArrowRight className="w-3 h-3" />
                        </span>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>

            {/* Sidebar */}
            <div className="lg:col-span-1">
              <div className="sticky top-24 space-y-6">
                <div className="bg-[#141210] rounded-xl border border-[rgba(200,169,126,0.1)] p-6">
                  <h3 className="text-[#F5F0EB] font-semibold mb-4">Categories</h3>
                  <ul className="space-y-2">
                    {categories.map((cat) => (
                      <li key={cat}>
                        <button className="text-[#A8A29E] text-sm hover:text-[#C8A97E] transition-colors">
                          {cat}
                        </button>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="bg-[#141210] rounded-xl border border-[rgba(200,169,126,0.1)] p-6">
                  <h3 className="text-[#F5F0EB] font-semibold mb-4">Recent Posts</h3>
                  <ul className="space-y-3">
                    {posts.slice(0, 3).map((post, i) => (
                      <li key={i} className="group cursor-pointer">
                        <p className="text-[#F5F0EB] text-sm font-medium group-hover:text-[#C8A97E] transition-colors line-clamp-2">{post.title}</p>
                        <p className="text-[#6B6560] text-xs mt-1">{post.date}</p>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
