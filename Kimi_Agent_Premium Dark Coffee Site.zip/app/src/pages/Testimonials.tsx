import { motion } from 'framer-motion'
import { Star } from 'lucide-react'
import { SectionHeader } from '@/components/SectionHeader'

const reviews = [
  { name: 'Sarah Mitchell', date: 'Dec 2024', rating: 5, quote: 'The most exquisite coffee experience I\'ve ever had. The ambiance, the flavors, the service — absolutely impeccable. NOIR Brew has set a new standard for what a coffee shop should be.' },
  { name: 'James Chen', date: 'Nov 2024', rating: 5, quote: 'NOIR Brew has become my daily ritual. Their cold brew is unlike anything else in the city — smooth, complex, and perfectly balanced. The staff remembers my order every time.' },
  { name: 'Elena Rodriguez', date: 'Nov 2024', rating: 5, quote: 'We hosted our company event here and it was perfect. The catering was exceptional, the venue is stunning, and our guests are still talking about it weeks later.' },
  { name: 'Michael Torres', date: 'Oct 2024', rating: 4, quote: 'Beautiful space and incredible coffee. The attention to detail in every drink is remarkable. My only wish is that they had more locations! ' },
  { name: 'Amanda Foster', date: 'Oct 2024', rating: 5, quote: 'The Tiramisu here is out of this world. Paired with their signature cappuccino, it is the perfect afternoon treat. I drive 30 minutes just for this experience.' },
  { name: 'David Kim', date: 'Sep 2024', rating: 5, quote: 'As a coffee enthusiast, I am very particular about my espresso. NOIR Brew exceeded every expectation. Their single-origin selection is curated with obvious expertise.' },
]

export default function Testimonials() {
  return (
    <div className="pt-[72px]">
      <section className="relative h-[40vh] flex items-center justify-center">
        <div className="absolute inset-0">
          <img src="/images/latte.jpg" alt="Testimonials" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-[#0A0A0A]/70" />
        </div>
        <div className="relative z-10 text-center">
          <h1 className="font-['Playfair_Display'] text-4xl md:text-5xl font-bold text-[#F5F0EB]">Guest Reviews</h1>
        </div>
      </section>

      <section className="section-padding bg-[#0A0A0A]">
        <div className="container-premium">
          <SectionHeader eyebrow="Testimonials" title="What Our Guests Say" />

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {reviews.map((review, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.05 }}
                className="card-premium p-6"
              >
                <div className="flex gap-1 mb-4">
                  {Array.from({ length: 5 }).map((_, j) => (
                    <Star key={j} className={`w-4 h-4 ${j < review.rating ? 'fill-[#C8A97E] text-[#C8A97E]' : 'text-[#3a3530]'}`} />
                  ))}
                </div>
                <p className="text-[#F5F0EB] italic leading-relaxed">&ldquo;{review.quote}&rdquo;</p>
                <div className="mt-4 flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-[#C8A97E]/15 flex items-center justify-center">
                    <span className="text-[#C8A97E] text-sm font-semibold">{review.name.charAt(0)}</span>
                  </div>
                  <div>
                    <p className="text-[#F5F0EB] text-sm font-medium">{review.name}</p>
                    <p className="text-[#6B6560] text-xs">{review.date}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  )
}
