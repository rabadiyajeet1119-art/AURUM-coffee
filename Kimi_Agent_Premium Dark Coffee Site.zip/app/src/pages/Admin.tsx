import { useEffect } from 'react'
import { useNavigate } from 'react-router'
import { motion } from 'framer-motion'
import { Shield, Users, ShoppingBag, Calendar, MessageSquare, Trash2, CheckCircle, DollarSign } from 'lucide-react'
import { useAuth } from '@/hooks/useAuth'
import { trpc } from '@/providers/trpc'
import { toast } from 'sonner'

export default function Admin() {
  const navigate = useNavigate()
  const { user, isAdmin, isLoading } = useAuth()

  useEffect(() => {
    if (!isLoading && !user) {
      navigate('/login')
    }
    if (!isLoading && user && !isAdmin) {
      navigate('/')
      toast.error('Access denied: Admin only')
    }
  }, [isLoading, user, isAdmin, navigate])

  if (isLoading) {
    return (
      <div className="pt-[72px] min-h-screen flex items-center justify-center bg-[#0A0A0A]">
        <div className="text-[#A8A29E]">Loading...</div>
      </div>
    )
  }

  if (!isAdmin) return null

  return (
    <div className="pt-[72px] min-h-screen bg-[#0A0A0A]">
      <div className="container-premium py-8">
        <div className="flex items-center gap-3 mb-8">
          <Shield className="w-6 h-6 text-[#C8A97E]" />
          <h1 className="font-['Playfair_Display'] text-2xl font-bold text-[#F5F0EB]">Admin Dashboard</h1>
        </div>

        <StatsCards />
        <MessagesTable />
        <RecentReservations />
      </div>
    </div>
  )
}

function StatsCards() {
  const { data: stats } = trpc.admin.stats.useQuery(undefined, { retry: false })

  const cards = [
    { label: 'Total Users', value: stats?.totalUsers ?? 0, icon: Users, color: '#C8A97E' },
    { label: 'Total Orders', value: stats?.totalOrders ?? 0, icon: ShoppingBag, color: '#8B9A46' },
    { label: 'Reservations', value: stats?.totalReservations ?? 0, icon: Calendar, color: '#7B8FA1' },
    { label: 'Messages', value: stats?.totalMessages ?? 0, icon: MessageSquare, color: '#A67B5B' },
    { label: 'Unread', value: stats?.unreadMessages ?? 0, icon: MessageSquare, color: '#C85A54' },
    { label: 'Revenue', value: `$${(stats?.revenue ?? 0).toFixed(2)}`, icon: DollarSign, color: '#B8860B' },
  ]

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-8"
    >
      {cards.map((card, i) => (
        <div key={i} className="bg-[#141210] rounded-xl border border-[rgba(200,169,126,0.1)] p-5">
          <div className="flex items-center justify-between mb-3">
            <card.icon className="w-5 h-5" style={{ color: card.color }} />
            <span className="text-xs text-[#6B6560]">{card.label}</span>
          </div>
          <p className="text-2xl font-bold text-[#F5F0EB]">{card.value}</p>
        </div>
      ))}
    </motion.div>
  )
}

function MessagesTable() {
  const utils = trpc.useUtils()
  const { data: messages, isLoading } = trpc.contact.list.useQuery(undefined, { retry: false })

  const markRead = trpc.contact.markRead.useMutation({
    onSuccess: () => { utils.contact.list.invalidate(); toast.success('Marked as read') },
  })

  const deleteMsg = trpc.contact.delete.useMutation({
    onSuccess: () => { utils.contact.list.invalidate(); toast.success('Message deleted') },
  })

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.1 }}
      className="bg-[#141210] rounded-xl border border-[rgba(200,169,126,0.1)] p-6 mb-8"
    >
      <h2 className="font-['Playfair_Display'] text-xl font-bold text-[#F5F0EB] mb-4 flex items-center gap-2">
        <MessageSquare className="w-5 h-5 text-[#C8A97E]" /> Contact Messages
      </h2>

      {isLoading ? (
        <p className="text-[#A8A29E]">Loading...</p>
      ) : !messages || messages.length === 0 ? (
        <p className="text-[#6B6560] text-sm">No messages yet</p>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[rgba(200,169,126,0.1)]">
                <th className="text-left py-3 px-2 text-[#A8A29E] font-medium">Name</th>
                <th className="text-left py-3 px-2 text-[#A8A29E] font-medium">Email</th>
                <th className="text-left py-3 px-2 text-[#A8A29E] font-medium">Subject</th>
                <th className="text-left py-3 px-2 text-[#A8A29E] font-medium">Message</th>
                <th className="text-left py-3 px-2 text-[#A8A29E] font-medium">Status</th>
                <th className="text-right py-3 px-2 text-[#A8A29E] font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {messages.map((msg) => (
                <tr key={msg.id} className="border-b border-[rgba(200,169,126,0.05)] hover:bg-[#1C1917]/50">
                  <td className="py-3 px-2 text-[#F5F0EB]">{msg.name}</td>
                  <td className="py-3 px-2 text-[#A8A29E]">{msg.email}</td>
                  <td className="py-3 px-2 text-[#A8A29E]">{msg.subject || '-'}</td>
                  <td className="py-3 px-2 text-[#A8A29E] max-w-[200px] truncate">{msg.message}</td>
                  <td className="py-3 px-2">
                    {msg.isRead ? (
                      <span className="text-green-400 text-xs">Read</span>
                    ) : (
                      <span className="text-[#C8A97E] text-xs font-medium">New</span>
                    )}
                  </td>
                  <td className="py-3 px-2 text-right">
                    <div className="flex items-center justify-end gap-2">
                      {!msg.isRead && (
                        <button
                          onClick={() => markRead.mutate({ id: msg.id })}
                          className="w-8 h-8 rounded-lg bg-green-500/10 flex items-center justify-center text-green-400 hover:bg-green-500/20 transition-colors"
                          title="Mark as read"
                        >
                          <CheckCircle className="w-4 h-4" />
                        </button>
                      )}
                      <button
                        onClick={() => { if (confirm('Delete this message?')) deleteMsg.mutate({ id: msg.id }) }}
                        className="w-8 h-8 rounded-lg bg-red-500/10 flex items-center justify-center text-red-400 hover:bg-red-500/20 transition-colors"
                        title="Delete"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </motion.div>
  )
}

function RecentReservations() {
  const { data: reservations, isLoading } = trpc.reservation.list.useQuery(undefined, { retry: false })

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.2 }}
      className="bg-[#141210] rounded-xl border border-[rgba(200,169,126,0.1)] p-6"
    >
      <h2 className="font-['Playfair_Display'] text-xl font-bold text-[#F5F0EB] mb-4 flex items-center gap-2">
        <Calendar className="w-5 h-5 text-[#C8A97E]" /> Recent Reservations
      </h2>

      {isLoading ? (
        <p className="text-[#A8A29E]">Loading...</p>
      ) : !reservations || reservations.length === 0 ? (
        <p className="text-[#6B6560] text-sm">No reservations yet</p>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[rgba(200,169,126,0.1)]">
                <th className="text-left py-3 px-2 text-[#A8A29E] font-medium">Name</th>
                <th className="text-left py-3 px-2 text-[#A8A29E] font-medium">Date</th>
                <th className="text-left py-3 px-2 text-[#A8A29E] font-medium">Time</th>
                <th className="text-left py-3 px-2 text-[#A8A29E] font-medium">Guests</th>
                <th className="text-left py-3 px-2 text-[#A8A29E] font-medium">Status</th>
              </tr>
            </thead>
            <tbody>
              {reservations.slice(0, 10).map((r) => (
                <tr key={r.id} className="border-b border-[rgba(200,169,126,0.05)] hover:bg-[#1C1917]/50">
                  <td className="py-3 px-2 text-[#F5F0EB]">{r.name}</td>
                  <td className="py-3 px-2 text-[#A8A29E]">{r.date ? new Date(r.date).toLocaleDateString() : '-'}</td>
                  <td className="py-3 px-2 text-[#A8A29E]">{r.time}</td>
                  <td className="py-3 px-2 text-[#A8A29E]">{r.guests}</td>
                  <td className="py-3 px-2">
                    <span className={`text-xs px-2 py-1 rounded-full ${
                      r.status === 'confirmed' ? 'bg-green-500/10 text-green-400' :
                      r.status === 'cancelled' ? 'bg-red-500/10 text-red-400' :
                      'bg-[#C8A97E]/10 text-[#C8A97E]'
                    }`}>
                      {r.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </motion.div>
  )
}
