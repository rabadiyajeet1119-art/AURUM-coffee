import { Link } from 'react-router'
import { motion } from 'framer-motion'
import { ArrowLeft, Coffee } from 'lucide-react'

export default function NotFound() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-[#0A0A0A] px-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <Coffee className="w-16 h-16 text-[#C8A97E] mx-auto mb-6" />
        <h1 className="font-['Playfair_Display'] text-6xl md:text-8xl font-bold text-[#F5F0EB]">404</h1>
        <p className="text-[#A8A29E] mt-4 text-lg">This page has gone cold.</p>
        <p className="text-[#6B6560] text-sm mt-2">The page you are looking for does not exist or has been moved.</p>
        <Link to="/" className="btn-primary mt-8 inline-flex">
          <ArrowLeft className="w-4 h-4" />
          Back to Home
        </Link>
      </motion.div>
    </div>
  )
}
