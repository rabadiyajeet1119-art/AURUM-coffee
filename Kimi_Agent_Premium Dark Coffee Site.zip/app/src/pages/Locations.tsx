import { motion } from 'framer-motion'
import { MapPin, Clock, Wifi, Car, Armchair, Phone, Navigation } from 'lucide-react'

const locations = [
  {
    name: 'NOIR Brew - Flagship',
    address: '123 Elegance Avenue, Suite 100, New York, NY 10001',
    hours: 'Mon-Fri: 7AM-10PM, Sat-Sun: 8AM-11PM',
    features: ['WiFi', 'Parking', 'Seating'],
    phone: '+1 (555) 234-5678',
    image: '/images/gallery-1.jpg',
  },
  {
    name: 'NOIR Brew - Downtown',
    address: '456 Main Street, New York, NY 10005',
    hours: 'Mon-Fri: 6:30AM-9PM, Sat-Sun: 7AM-10PM',
    features: ['WiFi', 'Seating'],
    phone: '+1 (555) 345-6789',
    image: '/images/gallery-3.jpg',
  },
]

const featureIcons: Record<string, React.ReactNode> = {
  WiFi: <Wifi className="w-3 h-3" />,
  Parking: <Car className="w-3 h-3" />,
  Seating: <Armchair className="w-3 h-3" />,
}

export default function Locations() {
  return (
    <div className="pt-[72px]">
      <section className="relative h-[40vh] flex items-center justify-center">
        <div className="absolute inset-0">
          <img src="/images/gallery-1.jpg" alt="Locations" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-[#0A0A0A]/70" />
        </div>
        <div className="relative z-10 text-center">
          <h1 className="font-['Playfair_Display'] text-4xl md:text-5xl font-bold text-[#F5F0EB]">Our Locations</h1>
        </div>
      </section>

      <section className="section-padding bg-[#0A0A0A]">
        <div className="container-premium">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {locations.map((loc, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="card-premium overflow-hidden"
              >
                <div className="aspect-[16/9] overflow-hidden">
                  <img src={loc.image} alt={loc.name} className="w-full h-full object-cover hover:scale-105 transition-transform duration-500" />
                </div>
                <div className="p-6">
                  <h3 className="font-['Playfair_Display'] text-xl font-bold text-[#F5F0EB]">{loc.name}</h3>
                  <div className="mt-4 space-y-3">
                    <div className="flex items-start gap-3">
                      <MapPin className="w-4 h-4 text-[#C8A97E] mt-0.5 shrink-0" />
                      <p className="text-[#A8A29E] text-sm">{loc.address}</p>
                    </div>
                    <div className="flex items-start gap-3">
                      <Clock className="w-4 h-4 text-[#C8A97E] mt-0.5 shrink-0" />
                      <p className="text-[#A8A29E] text-sm">{loc.hours}</p>
                    </div>
                    <div className="flex items-center gap-3">
                      <Phone className="w-4 h-4 text-[#C8A97E] shrink-0" />
                      <p className="text-[#A8A29E] text-sm">{loc.phone}</p>
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-2 mt-4">
                    {loc.features.map((f) => (
                      <span key={f} className="inline-flex items-center gap-1 text-xs text-[#C8A97E] bg-[#C8A97E]/10 px-3 py-1 rounded-full">
                        {featureIcons[f]} {f}
                      </span>
                    ))}
                  </div>
                  <div className="flex gap-3 mt-6">
                    <a href={`https://maps.google.com/?q=${encodeURIComponent(loc.address)}`} target="_blank" rel="noopener noreferrer" className="flex-1 btn-primary text-xs py-2 justify-center">
                      <Navigation className="w-3 h-3" /> Directions
                    </a>
                    <a href={`tel:${loc.phone}`} className="flex-1 btn-outline text-xs py-2 justify-center">
                      <Phone className="w-3 h-3" /> Call
                    </a>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  )
}
