import { z } from "zod";
import { createRouter, publicQuery, adminQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { orders } from "@db/schema";
import { eq, desc } from "drizzle-orm";

export const orderRouter = createRouter({
  create: publicQuery.input(
    z.object({
      customerName: z.string().min(1),
      customerEmail: z.string().email(),
      customerPhone: z.string().optional(),
      items: z.array(z.object({
        id: z.number(),
        name: z.string(),
        quantity: z.number(),
        price: z.string(),
      })),
      subtotal: z.string(),
      tax: z.string(),
      total: z.string(),
      orderType: z.enum(["pickup", "delivery"]),
      specialInstructions: z.string().optional(),
      promoCode: z.string().optional(),
    }),
  ).mutation(async ({ input }) => {
    const db = getDb();
    const result = await db.insert(orders).values({
      ...input,
      status: "pending",
    });
    const id = Number(result[0].insertId);
    const items = await db.select().from(orders).where(eq(orders.id, id)).limit(1);
    return items[0];
  }),

  list: adminQuery.query(async () => {
    const db = getDb();
    return db.select().from(orders).orderBy(desc(orders.createdAt));
  }),

  updateStatus: adminQuery.input(
    z.object({
      id: z.number(),
      status: z.string(),
    }),
  ).mutation(async ({ input }) => {
    const db = getDb();
    await db
      .update(orders)
      .set({ status: input.status })
      .where(eq(orders.id, input.id));
    const items = await db.select().from(orders).where(eq(orders.id, input.id)).limit(1);
    return items[0];
  }),
});
