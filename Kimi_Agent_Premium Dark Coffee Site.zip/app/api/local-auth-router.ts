import { z } from "zod";
import bcrypt from "bcryptjs";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { localUsers } from "@db/schema";
import { eq } from "drizzle-orm";
import { createLocalToken, verifyLocalToken } from "./local-auth-utils";
import { TRPCError } from "@trpc/server";

export const localAuthRouter = createRouter({
  register: publicQuery.input(
    z.object({
      username: z.string().min(3).max(50),
      password: z.string().min(6),
      displayName: z.string().optional(),
      email: z.string().email().optional(),
    }),
  ).mutation(async ({ input }) => {
    const db = getDb();

    // Check if username already exists
    const existing = await db
      .select()
      .from(localUsers)
      .where(eq(localUsers.username, input.username))
      .limit(1);

    if (existing.length > 0) {
      throw new TRPCError({
        code: "CONFLICT",
        message: "Username already exists",
      });
    }

    // Hash password
    const passwordHash = await bcrypt.hash(input.password, 10);

    // Create user
    const result = await db.insert(localUsers).values({
      username: input.username,
      displayName: input.displayName ?? input.username,
      email: input.email,
      passwordHash,
    });

    const userId = Number(result[0].insertId);

    // Generate token
    const token = createLocalToken(userId);

    return {
      token,
      user: {
        id: userId,
        username: input.username,
        displayName: input.displayName ?? input.username,
        role: "user" as const,
      },
    };
  }),

  login: publicQuery.input(
    z.object({
      username: z.string(),
      password: z.string(),
    }),
  ).mutation(async ({ input }) => {
    const db = getDb();

    const users = await db
      .select()
      .from(localUsers)
      .where(eq(localUsers.username, input.username))
      .limit(1);

    if (users.length === 0) {
      throw new TRPCError({
        code: "UNAUTHORIZED",
        message: "Invalid username or password",
      });
    }

    const user = users[0];
    const valid = await bcrypt.compare(input.password, user.passwordHash);

    if (!valid) {
      throw new TRPCError({
        code: "UNAUTHORIZED",
        message: "Invalid username or password",
      });
    }

    const token = createLocalToken(user.id);

    return {
      token,
      user: {
        id: user.id,
        username: user.username,
        displayName: user.displayName ?? user.username,
        role: user.role as "user" | "admin",
      },
    };
  }),

  me: publicQuery.query(async ({ ctx }) => {
    const localAuthToken = ctx.req.headers.get("x-local-auth-token");
    if (!localAuthToken) return null;

    const user = await verifyLocalToken(localAuthToken);
    if (!user) return null;

    return {
      id: user.id,
      username: user.username,
      displayName: user.displayName ?? user.username,
      name: user.displayName ?? user.username,
      email: user.email,
      role: user.role as "user" | "admin",
    };
  }),
});
