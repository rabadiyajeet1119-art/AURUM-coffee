import { authRouter } from "./auth-router";
import { localAuthRouter } from "./local-auth-router";
import { menuRouter } from "./menu-router";
import { reservationRouter } from "./reservation-router";
import { contactRouter } from "./contact-router";
import { orderRouter } from "./order-router";
import { adminRouter } from "./admin-router";
import { aiRouter } from "./ai-router";
import { createRouter, publicQuery } from "./middleware";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  localAuth: localAuthRouter,
  menu: menuRouter,
  reservation: reservationRouter,
  contact: contactRouter,
  order: orderRouter,
  admin: adminRouter,
  ai: aiRouter,
});

export type AppRouter = typeof appRouter;
