import { z } from "zod";
import { createRouter, publicQuery, adminQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { menuItems } from "@db/schema";
import { eq, and } from "drizzle-orm";

export const menuRouter = createRouter({
  list: publicQuery.input(
    z.object({
      category: z.string().optional(),
      search: z.string().optional(),
    }).optional(),
  ).query(async ({ input }) => {
    const db = getDb();
    const conditions = [];

    if (input?.category) {
      conditions.push(eq(menuItems.category, input.category));
    }

    if (conditions.length > 0) {
      return db.select().from(menuItems).where(and(...conditions));
    }

    return db.select().from(menuItems);
  }),

  getById: publicQuery.input(z.object({ id: z.number() })).query(async ({ input }) => {
    const db = getDb();
    const items = await db
      .select()
      .from(menuItems)
      .where(eq(menuItems.id, input.id))
      .limit(1);
    return items[0] ?? null;
  }),

  create: adminQuery.input(
    z.object({
      name: z.string().min(1),
      description: z.string().optional(),
      price: z.string().or(z.number()),
      category: z.string().min(1),
      subcategory: z.string().optional(),
      image: z.string().optional(),
      badges: z.array(z.string()).optional(),
    }),
  ).mutation(async ({ input }) => {
    const db = getDb();
    const price = typeof input.price === "number" ? input.price.toFixed(2) : input.price;
    const result = await db.insert(menuItems).values({
      name: input.name,
      description: input.description,
      price,
      category: input.category,
      subcategory: input.subcategory,
      image: input.image,
      badges: input.badges,
    });
    const id = Number(result[0].insertId);
    const items = await db.select().from(menuItems).where(eq(menuItems.id, id)).limit(1);
    return items[0];
  }),

  update: adminQuery.input(
    z.object({
      id: z.number(),
      name: z.string().optional(),
      description: z.string().optional(),
      price: z.string().or(z.number()).optional(),
      category: z.string().optional(),
      subcategory: z.string().optional(),
      image: z.string().optional(),
      badges: z.array(z.string()).optional(),
      isAvailable: z.boolean().optional(),
    }),
  ).mutation(async ({ input }) => {
    const db = getDb();
    const { id, ...rawData } = input;
    const data: Record<string, unknown> = {};
    for (const [key, value] of Object.entries(rawData)) {
      if (value !== undefined) {
        data[key] = key === "price" && typeof value === "number" ? value.toFixed(2) : value;
      }
    }
    await db.update(menuItems).set(data).where(eq(menuItems.id, id));
    const items = await db.select().from(menuItems).where(eq(menuItems.id, id)).limit(1);
    return items[0];
  }),

  delete: adminQuery.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
    const db = getDb();
    await db.delete(menuItems).where(eq(menuItems.id, input.id));
    return { success: true };
  }),
});
