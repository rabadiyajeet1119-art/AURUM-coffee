import { z } from "zod";
import { createRouter, publicQuery, adminQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { contactMessages } from "@db/schema";
import { eq, desc } from "drizzle-orm";

export const contactRouter = createRouter({
  submit: publicQuery.input(
    z.object({
      name: z.string().min(1),
      email: z.string().email(),
      phone: z.string().optional(),
      subject: z.string().optional(),
      message: z.string().min(1),
    }),
  ).mutation(async ({ input }) => {
    const db = getDb();
    const result = await db.insert(contactMessages).values(input);
    const id = Number(result[0].insertId);
    const items = await db.select().from(contactMessages).where(eq(contactMessages.id, id)).limit(1);
    return items[0];
  }),

  list: adminQuery.query(async () => {
    const db = getDb();
    return db.select().from(contactMessages).orderBy(desc(contactMessages.createdAt));
  }),

  markRead: adminQuery.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
    const db = getDb();
    await db
      .update(contactMessages)
      .set({ isRead: true })
      .where(eq(contactMessages.id, input.id));
    const items = await db.select().from(contactMessages).where(eq(contactMessages.id, input.id)).limit(1);
    return items[0];
  }),

  delete: adminQuery.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
    const db = getDb();
    await db.delete(contactMessages).where(eq(contactMessages.id, input.id));
    return { success: true };
  }),
});
