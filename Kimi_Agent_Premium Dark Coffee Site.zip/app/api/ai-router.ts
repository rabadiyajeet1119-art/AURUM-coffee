import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";

const SYSTEM_PROMPT = `You are the AI assistant for NOIR Brew, a premium specialty coffee shop. You help customers with:
- Menu recommendations and descriptions
- Coffee brewing tips and knowledge
- Information about the cafe (hours, location, events)
- Order and reservation assistance
- General coffee education

Be warm, knowledgeable, and concise. Use a sophisticated but approachable tone that matches the NOIR brand.

Key information about NOIR Brew:
- Located in the heart of the city with elegant atmosphere
- Open daily: 7:00 AM - 10:00 PM
- Specialty: Single-origin espresso, artisan lattes, cold brew
- Also serves: Pastries, breakfast items, desserts
- Offers: WiFi, table reservations, event hosting, catering
- Known for: Premium beans, master roasters, artisan craft`;

export const aiRouter = createRouter({
  chat: publicQuery.input(
    z.object({
      message: z.string().min(1),
      history: z.array(z.object({
        role: z.enum(["user", "assistant"]),
        content: z.string(),
      })).optional(),
    }),
  ).mutation(async ({ input }) => {
    try {
      const response = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${process.env.OPENAI_API_KEY || "demo-key"}`,
        },
        body: JSON.stringify({
          model: "gpt-3.5-turbo",
          messages: [
            { role: "system", content: SYSTEM_PROMPT },
            ...(input.history ?? []).slice(-6),
            { role: "user", content: input.message },
          ],
          max_tokens: 500,
          temperature: 0.7,
        }),
      });

      if (!response.ok) {
        return {
          reply: getFallbackResponse(input.message),
        };
      }

      const data = await response.json() as {
        choices?: Array<{ message?: { content?: string } }>;
      };
      return {
        reply: data.choices?.[0]?.message?.content ?? getFallbackResponse(input.message),
      };
    } catch {
      return {
        reply: getFallbackResponse(input.message),
      };
    }
  }),
});

function getFallbackResponse(message: string): string {
  const lower = message.toLowerCase();

  if (lower.includes("menu") || lower.includes("drink") || lower.includes("coffee")) {
    return "Our signature drinks include our Single Origin Espresso, Artisan Latte, and Cold Brew. We also offer Cappuccino, Flat White, Matcha Latte, and a selection of premium teas. For food, try our Almond Croissant, Avocado Toast, or Tiramisu. You can view our full menu on the Menu page!";
  }
  if (lower.includes("hour") || lower.includes("open")) {
    return "We're open daily from 7:00 AM to 10:00 PM. Our kitchen closes at 9:00 PM, but coffee is served until closing.";
  }
  if (lower.includes("location") || lower.includes("address") || lower.includes("where")) {
    return "NOIR Brew is located in the heart of the city. Visit our Locations page for the exact address and directions. We offer convenient parking nearby!";
  }
  if (lower.includes("reservation") || lower.includes("book") || lower.includes("table")) {
    return "Yes, you can book a table! Visit our Reservations page to select your preferred date, time, and party size. We recommend booking in advance for weekends.";
  }
  if (lower.includes("order") || lower.includes("delivery") || lower.includes("pickup")) {
    return "You can place an order for pickup or delivery through our Order Online page. Simply browse our menu, add items to your cart, and checkout!";
  }
  if (lower.includes("wifi") || lower.includes("internet")) {
    return "Yes, we offer complimentary high-speed WiFi for all our guests. Ask our staff for the password when you visit!";
  }
  if (lower.includes("event") || lower.includes("catering") || lower.includes("party")) {
    return "We host private events and offer catering services! Whether it's a birthday celebration, corporate meeting, or private gathering, our Events & Catering page has all the details and an inquiry form.";
  }
  if (lower.includes("vegan") || lower.includes("vegetarian") || lower.includes("dairy-free")) {
    return "We offer several vegan and dairy-free options! Our Matcha Latte and Cold Brew can be made with oat milk. We also have vegan pastries available daily.";
  }

  return "Thank you for reaching out! I'd be happy to help. Could you tell me more about what you're looking for? You can ask about our menu, hours, reservations, events, or anything else about NOIR Brew.";
}
