import { createRouter, adminQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { users, localUsers, orders, reservations, contactMessages } from "@db/schema";
import { sql } from "drizzle-orm";

export const adminRouter = createRouter({
  stats: adminQuery.query(async () => {
    const db = getDb();

    const [userCount] = await db.select({ count: sql<number>`count(*)` }).from(users);
    const [localUserCount] = await db.select({ count: sql<number>`count(*)` }).from(localUsers);
    const [orderCount] = await db.select({ count: sql<number>`count(*)` }).from(orders);
    const [reservationCount] = await db.select({ count: sql<number>`count(*)` }).from(reservations);
    const [messageCount] = await db.select({ count: sql<number>`count(*)` }).from(contactMessages);
    const [unreadCount] = await db
      .select({ count: sql<number>`count(*)` })
      .from(contactMessages)
      .where(sql`is_read = false`);
    const [revenueResult] = await db
      .select({ total: sql<string>`COALESCE(SUM(total), 0)` })
      .from(orders);

    return {
      totalUsers: Number(userCount.count) + Number(localUserCount.count),
      totalOrders: Number(orderCount.count),
      totalReservations: Number(reservationCount.count),
      totalMessages: Number(messageCount.count),
      unreadMessages: Number(unreadCount.count),
      revenue: Number(revenueResult.total) || 0,
    };
  }),

  recentOrders: adminQuery.query(async () => {
    const db = getDb();
    return db.select().from(orders).orderBy(sql`created_at DESC`).limit(10);
  }),

  recentReservations: adminQuery.query(async () => {
    const db = getDb();
    return db.select().from(reservations).orderBy(sql`created_at DESC`).limit(10);
  }),
});
