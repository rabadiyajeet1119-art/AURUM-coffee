import jwt from "jsonwebtoken";
import { env } from "./lib/env";
import { getDb } from "./queries/connection";
import { localUsers } from "@db/schema";
import { eq } from "drizzle-orm";

const JWT_EXPIRES_IN = "7d";

export function createLocalToken(userId: number): string {
  return jwt.sign({ userId, type: "local" }, env.jwtSecret, {
    expiresIn: JWT_EXPIRES_IN,
  });
}

export async function verifyLocalToken(token: string) {
  try {
    const decoded = jwt.verify(token, env.jwtSecret, {
      clockTolerance: 60,
    }) as { userId: number; type: string };

    if (decoded.type !== "local") return null;

    const db = getDb();
    const user = await db
      .select()
      .from(localUsers)
      .where(eq(localUsers.id, decoded.userId))
      .limit(1);

    return user[0] ?? null;
  } catch {
    return null;
  }
}
