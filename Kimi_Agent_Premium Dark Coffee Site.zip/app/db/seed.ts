import { getDb } from "../api/queries/connection";
import { menuItems } from "./schema";

async function seed() {
  console.log("Seeding menu items...");
  const db = getDb();

  const items = [
    {
      name: "Single Origin Espresso",
      description: "Rich, complex espresso crafted from ethically sourced single-origin beans. Notes of dark chocolate and caramel.",
      price: "3.50",
      category: "Coffee",
      subcategory: "Espresso",
      image: "/images/espresso.jpg",
      badges: ["Best Seller"],
    },
    {
      name: "Double Espresso",
      description: "An intense double shot of our house blend. Perfect for those who need an extra kick.",
      price: "4.50",
      category: "Coffee",
      subcategory: "Espresso",
      image: "/images/espresso.jpg",
      badges: [],
    },
    {
      name: "Artisan Cappuccino",
      description: "Silky microfoam over rich espresso, finished with a dusting of cocoa. Our signature preparation.",
      price: "5.50",
      category: "Coffee",
      subcategory: "Milk Coffee",
      image: "/images/cappuccino.jpg",
      badges: ["Best Seller", "Recommended"],
    },
    {
      name: "Classic Latte",
      description: "Smooth espresso with steamed milk, topped with a thin layer of foam. Simple perfection.",
      price: "5.50",
      category: "Coffee",
      subcategory: "Milk Coffee",
      image: "/images/latte.jpg",
      badges: [],
    },
    {
      name: "Flat White",
      description: "Australian-style with velvety microfoam and a stronger coffee-to-milk ratio.",
      price: "5.00",
      category: "Coffee",
      subcategory: "Milk Coffee",
      image: "/images/flat-white.jpg",
      badges: [],
    },
    {
      name: "Signature Cold Brew",
      description: "Slow-steeped for 18 hours for a smooth, naturally sweet flavor with low acidity.",
      price: "6.00",
      category: "Coffee",
      subcategory: "Cold",
      image: "/images/cold-brew.jpg",
      badges: ["New"],
    },
    {
      name: "Iced Latte",
      description: "Espresso poured over ice with cold milk. Refreshing and perfectly balanced.",
      price: "6.50",
      category: "Coffee",
      subcategory: "Cold",
      image: "/images/iced-latte.jpg",
      badges: [],
    },
    {
      name: "Matcha Latte",
      description: "Ceremonial-grade Japanese matcha whisked with steamed milk. Earthy and vibrant.",
      price: "6.50",
      category: "Tea",
      subcategory: "Specialty",
      image: "/images/matcha.jpg",
      badges: ["Recommended"],
    },
    {
      name: "Earl Grey",
      description: "Classic bergamot-infused black tea, served with a slice of lemon.",
      price: "4.50",
      category: "Tea",
      subcategory: "Classic",
      image: "/images/matcha.jpg",
      badges: [],
    },
    {
      name: "Hot Chocolate",
      description: "Rich Belgian chocolate melted into steamed milk, topped with whipped cream.",
      price: "5.50",
      category: "Beverage",
      subcategory: "Specialty",
      image: "/images/hot-chocolate.jpg",
      badges: [],
    },
    {
      name: "Avocado Toast",
      description: "Sourdough topped with smashed avocado, cherry tomatoes, microgreens, and a drizzle of olive oil.",
      price: "12.00",
      category: "Food",
      subcategory: "Breakfast",
      image: "/images/avocado-toast.jpg",
      badges: ["Recommended"],
    },
    {
      name: "Almond Croissant",
      description: "Buttery, flaky croissant filled with almond cream and topped with sliced almonds.",
      price: "5.50",
      category: "Food",
      subcategory: "Pastry",
      image: "/images/croissant.jpg",
      badges: [],
    },
    {
      name: "Classic Tiramisu",
      description: "Layers of espresso-soaked ladyfingers and mascarpone cream, dusted with cocoa powder.",
      price: "8.50",
      category: "Food",
      subcategory: "Dessert",
      image: "/images/tiramisu.jpg",
      badges: ["Best Seller"],
    },
    {
      name: "New York Cheesecake",
      description: "Creamy baked cheesecake with a graham cracker crust, served with berry compote.",
      price: "9.00",
      category: "Food",
      subcategory: "Dessert",
      image: "/images/cheesecake.jpg",
      badges: [],
    },
  ];

  for (const item of items) {
    await db.insert(menuItems).values(item);
  }

  console.log(`Seeded ${items.length} menu items.`);
}

seed().catch(console.error);
